package com.gesturedata.collector.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.gesturedata.collector.GestureApp;
import com.gesturedata.collector.data.db.GestureDao;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class HomeViewModel extends AndroidViewModel {

    public static class HomeStats {
        public int totalGestures;
        public int todayGestures;
        public int pendingUpload;
        public int streak;
    }

    private final MutableLiveData<HomeStats> statsLive = new MutableLiveData<>();
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final GestureDao gestureDao;

    public HomeViewModel(@NonNull Application application) {
        super(application);
        gestureDao = GestureApp.get().getRepository().getGestureDao();
        refreshStats();
    }

    public LiveData<HomeStats> getStats() { return statsLive; }

    public void refreshStats() {
        executor.execute(() -> {
            HomeStats s = new HomeStats();
            s.totalGestures = gestureDao.totalCount();

            long startOfDay = getStartOfDayMillis();
            s.todayGestures = gestureDao.countSince(startOfDay);
            s.pendingUpload = gestureDao.pendingUploadCount();
            s.streak = com.gesturedata.collector.util.PreferencesManager
                    .getInstance(getApplication()).getStreak();
            statsLive.postValue(s);
        });
    }

    private long getStartOfDayMillis() {
        java.util.Calendar cal = java.util.Calendar.getInstance();
        cal.set(java.util.Calendar.HOUR_OF_DAY, 0);
        cal.set(java.util.Calendar.MINUTE, 0);
        cal.set(java.util.Calendar.SECOND, 0);
        cal.set(java.util.Calendar.MILLISECOND, 0);
        return cal.getTimeInMillis();
    }
}
