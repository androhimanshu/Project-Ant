package com.gesturedata.collector.data.model;

import com.google.gson.annotations.SerializedName;

/**
 * Complete data for one pointer (finger) at a single MotionEvent moment.
 * Matches exactly the per-pointer fields the training pipeline expects.
 */
public class PointerSample {

    @SerializedName("pointer_id")
    public int pointerId;

    /** TOOL_TYPE_FINGER=1, TOOL_TYPE_STYLUS=2, TOOL_TYPE_MOUSE=3, TOOL_TYPE_ERASER=4 */
    @SerializedName("tool_type")
    public int toolType;

    /** View-local X coordinate */
    @SerializedName("x")
    public float x;

    /** View-local Y coordinate */
    @SerializedName("y")
    public float y;

    /** Screen-absolute X (only reliable for pointer index 0) */
    @SerializedName("raw_x")
    public float rawX;

    /** Screen-absolute Y (only reliable for pointer index 0) */
    @SerializedName("raw_y")
    public float rawY;

    /** Contact force 0.0–1.0 */
    @SerializedName("pressure")
    public float pressure;

    /** Actual skin-screen contact ellipse long axis (pixels) */
    @SerializedName("touch_major")
    public float touchMajor;

    /** Actual skin-screen contact ellipse short axis (pixels) */
    @SerializedName("touch_minor")
    public float touchMinor;

    /** Estimated tool area long axis — slightly larger than touch (pixels) */
    @SerializedName("tool_major")
    public float toolMajor;

    /** Estimated tool area short axis (pixels) */
    @SerializedName("tool_minor")
    public float toolMinor;

    /** Finger rotation angle in radians, range -PI/2 to PI/2 */
    @SerializedName("orientation")
    public float orientation;

    /** Finger lean along X axis (radians) */
    @SerializedName("tilt_x")
    public float tiltX;

    /** Finger lean along Y axis (radians) */
    @SerializedName("tilt_y")
    public float tiltY;

    /** Hover distance: 0.0 = touching, >0 = hovering */
    @SerializedName("distance")
    public float distance;

    public PointerSample() {}

    public PointerSample(int pointerId, int toolType,
                         float x, float y, float rawX, float rawY,
                         float pressure,
                         float touchMajor, float touchMinor,
                         float toolMajor, float toolMinor,
                         float orientation, float tiltX, float tiltY,
                         float distance) {
        this.pointerId   = pointerId;
        this.toolType    = toolType;
        this.x           = x;
        this.y           = y;
        this.rawX        = rawX;
        this.rawY        = rawY;
        this.pressure    = pressure;
        this.touchMajor  = touchMajor;
        this.touchMinor  = touchMinor;
        this.toolMajor   = toolMajor;
        this.toolMinor   = toolMinor;
        this.orientation = orientation;
        this.tiltX       = tiltX;
        this.tiltY       = tiltY;
        this.distance    = distance;
    }
}
