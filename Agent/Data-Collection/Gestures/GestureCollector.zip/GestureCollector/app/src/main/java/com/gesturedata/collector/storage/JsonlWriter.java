package com.gesturedata.collector.storage;

import com.gesturedata.collector.data.model.GestureRecord;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Writes GestureRecord objects as JSON Lines (.jsonl) — one record per line.
 *
 * Rules:
 * - flush() called after EVERY write — survive process kills
 * - UTF-8 encoding
 * - Never rewrite existing lines — append only
 * - One file per session
 */
public class JsonlWriter {

    private final File       sessionsDir;
    private final Gson       gson;

    private File             currentFile;
    private BufferedWriter   writer;

    public JsonlWriter(File sessionsDir) {
        this.sessionsDir = sessionsDir;
        this.gson = new GsonBuilder()
                .serializeNulls()
                .create();

        if (!sessionsDir.exists()) {
            sessionsDir.mkdirs();
        }
    }

    /**
     * Opens a new .jsonl file for the given session.
     * @return absolute path to the file
     */
    public synchronized String openSession(String sessionId) throws IOException {
        close();

        String timestamp = new SimpleDateFormat("yyyy_MM_dd_HHmmss", Locale.US)
                .format(new Date());
        String shortId = sessionId.length() >= 8
                ? sessionId.substring(0, 8)
                : sessionId;
        String fileName = "session_" + timestamp + "_" + shortId + ".jsonl";

        currentFile = new File(sessionsDir, fileName);
        writer = new BufferedWriter(new FileWriter(currentFile, true), 8192);

        return currentFile.getAbsolutePath();
    }

    /**
     * Appends one GestureRecord as a JSON line.
     * Flushes immediately — data survives app kill.
     */
    public synchronized void appendGesture(GestureRecord record) throws IOException {
        if (writer == null) {
            throw new IllegalStateException("No session open — call openSession() first");
        }
        String json = gson.toJson(record);
        writer.write(json);
        writer.newLine();
        writer.flush(); // flush every record
    }

    /**
     * Closes the writer. Safe to call even if not open.
     */
    public synchronized void close() {
        if (writer != null) {
            try { writer.close(); } catch (IOException ignored) {}
            writer = null;
        }
    }

    public synchronized String getCurrentFilePath() {
        return currentFile != null ? currentFile.getAbsolutePath() : null;
    }

    public synchronized long getCurrentFileSizeBytes() {
        return currentFile != null && currentFile.exists()
                ? currentFile.length()
                : 0L;
    }
}
