package com.gesturedata.collector.data.db;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.annotation.NonNull;

@Entity(tableName = "sessions")
public class SessionEntity {

    @PrimaryKey
    @NonNull
    public String sessionId;

    public long    startedAt;
    public long    endedAt;       // 0 = still active
    public int     gestureCount;
    public int     uploadedCount;
    public String  filePath;

    public SessionEntity() {}

    public SessionEntity(@NonNull String sessionId, long startedAt,
                         long endedAt, int gestureCount, int uploadedCount,
                         String filePath) {
        this.sessionId    = sessionId;
        this.startedAt    = startedAt;
        this.endedAt      = endedAt;
        this.gestureCount = gestureCount;
        this.uploadedCount= uploadedCount;
        this.filePath     = filePath;
    }
}
