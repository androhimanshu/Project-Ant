package com.gesturedata.collector.recording;

import com.gesturedata.collector.data.model.DerivedFeatures;
import com.gesturedata.collector.data.model.PointerSample;
import com.gesturedata.collector.data.model.TouchEvent;

import java.util.ArrayList;
import java.util.List;

/**
 * Computes all derived features from the raw touch event list.
 * Run on a background thread — never on the UI thread.
 */
public class DerivedFeatureComputer {

    private DerivedFeatureComputer() {}

    public static DerivedFeatures compute(List<TouchEvent> events) {
        if (events == null || events.isEmpty()) {
            return emptyFeatures();
        }

        // ── Pressure analysis ──────────────────────────────────────────────
        float pressurePeak = 0f;
        for (TouchEvent e : events) {
            if (e.pointers != null) {
                for (PointerSample p : e.pointers) {
                    if (p.pressure > pressurePeak) pressurePeak = p.pressure;
                }
            }
        }

        int pressureAttackMs  = computePressureAttackMs(events, pressurePeak);
        int pressureReleaseMs = computePressureReleaseMs(events);

        // ── Touch major peak ───────────────────────────────────────────────
        float touchMajorPeak = 0f;
        for (TouchEvent e : events) {
            if (e.pointers != null) {
                for (PointerSample p : e.pointers) {
                    if (p.touchMajor > touchMajorPeak) touchMajorPeak = p.touchMajor;
                }
            }
        }

        // ── Path extraction (primary pointer, MOVE events) ─────────────────
        List<float[]> path = extractPrimaryPath(events);

        // ── Jitter ────────────────────────────────────────────────────────
        float jitterAmplitudePx = computeJitter(path);

        // ── Path linearity ────────────────────────────────────────────────
        float pathLinearity = computePathLinearity(path);

        // ── Max displacement from start ───────────────────────────────────
        float maxDisplacement = computeMaxDisplacement(path);

        // ── Velocity profile ──────────────────────────────────────────────
        String velocityProfile = detectVelocityProfile(events);

        // ── Counts ────────────────────────────────────────────────────────
        int eventCount = events.size();
        float samplesPerEventAvg = computeSamplesPerEventAvg(events);

        return new DerivedFeatures(
                pressurePeak, pressureAttackMs, pressureReleaseMs,
                touchMajorPeak, jitterAmplitudePx, pathLinearity,
                velocityProfile, eventCount, samplesPerEventAvg,
                maxDisplacement);
    }

    // ── Private helpers ───────────────────────────────────────────────────

    private static int computePressureAttackMs(List<TouchEvent> events, float peak) {
        if (peak < 0.01f) return 0;
        float threshold = peak * 0.5f;
        for (TouchEvent e : events) {
            if ("MOVE".equals(e.action) && e.pointers != null && !e.pointers.isEmpty()) {
                if (e.pointers.get(0).pressure >= threshold) {
                    return e.tMs;
                }
            }
        }
        return 0;
    }

    private static int computePressureReleaseMs(List<TouchEvent> events) {
        int lastAboveThreshold = 0;
        int lastTms = 0;
        for (TouchEvent e : events) {
            if (e.pointers != null && !e.pointers.isEmpty()) {
                lastTms = e.tMs;
                if (e.pointers.get(0).pressure > 0.2f) {
                    lastAboveThreshold = e.tMs;
                }
            }
        }
        return lastTms - lastAboveThreshold;
    }

    private static List<float[]> extractPrimaryPath(List<TouchEvent> events) {
        List<float[]> path = new ArrayList<>();
        for (TouchEvent e : events) {
            if (e.pointers != null && !e.pointers.isEmpty()) {
                PointerSample p = e.pointers.get(0);
                path.add(new float[]{p.x, p.y, e.tMs});
            }
        }
        return path;
    }

    /**
     * Fit a straight line through the path using least squares,
     * then compute RMS of perpendicular residuals.
     */
    private static float computeJitter(List<float[]> path) {
        if (path.size() < 3) return 0f;

        int n = path.size();
        double sumX = 0, sumY = 0, sumXX = 0, sumXY = 0;
        for (float[] pt : path) {
            sumX  += pt[0];
            sumY  += pt[1];
            sumXX += pt[0] * pt[0];
            sumXY += pt[0] * pt[1];
        }
        double denom = n * sumXX - sumX * sumX;
        if (Math.abs(denom) < 1e-6) return 0f;

        // y = slope*x + intercept
        double slope     = (n * sumXY - sumX * sumY) / denom;
        double intercept = (sumY - slope * sumX) / n;
        // Line: slope*x - y + intercept = 0
        double lineLen = Math.sqrt(slope * slope + 1.0);

        double sumSq = 0;
        for (float[] pt : path) {
            double dist = Math.abs(slope * pt[0] - pt[1] + intercept) / lineLen;
            sumSq += dist * dist;
        }
        return (float) Math.sqrt(sumSq / n);
    }

    /**
     * Ratio of straight-line distance to actual path length.
     * 1.0 = perfectly straight, 0.0 = gesture went nowhere.
     */
    private static float computePathLinearity(List<float[]> path) {
        if (path.size() < 2) return 1f;

        float[] start = path.get(0);
        float[] end   = path.get(path.size() - 1);
        double straightLine = Math.hypot(end[0] - start[0], end[1] - start[1]);

        double actualLength = 0;
        for (int i = 1; i < path.size(); i++) {
            actualLength += Math.hypot(
                    path.get(i)[0] - path.get(i-1)[0],
                    path.get(i)[1] - path.get(i-1)[1]);
        }
        if (actualLength < 1f) return 1f;
        return (float) Math.min(1.0, straightLine / actualLength);
    }

    private static float computeMaxDisplacement(List<float[]> path) {
        if (path.isEmpty()) return 0f;
        float sx = path.get(0)[0], sy = path.get(0)[1];
        float maxDist = 0f;
        for (float[] pt : path) {
            float dist = (float) Math.hypot(pt[0] - sx, pt[1] - sy);
            if (dist > maxDist) maxDist = dist;
        }
        return maxDist;
    }

    /**
     * Detect velocity profile by comparing speed at 20%, 50%, and 80%
     * of gesture duration.
     */
    private static String detectVelocityProfile(List<TouchEvent> events) {
        if (events.size() < 5) return "linear";

        int total    = events.size();
        int idx20    = total / 5;
        int idx50    = total / 2;
        int idx80    = (total * 4) / 5;

        float v20 = instantaneousVelocity(events, idx20);
        float v50 = instantaneousVelocity(events, idx50);
        float v80 = instantaneousVelocity(events, idx80);

        float peak = Math.max(v20, Math.max(v50, v80));
        if (peak < 1f) return "linear";

        boolean fastStart = v20 > v50 * 1.3f && v20 > v80 * 1.3f;
        boolean fastEnd   = v80 > v20 * 1.3f && v80 > v50 * 1.3f;
        boolean fastMid   = v50 > v20 * 1.2f && v50 > v80 * 1.2f;

        if (fastStart) return "ease_out";
        if (fastEnd)   return "ease_in";
        if (fastMid)   return "ease_in_out";
        return "linear";
    }

    private static float instantaneousVelocity(List<TouchEvent> events, int idx) {
        if (idx <= 0 || idx >= events.size() - 1) return 0f;
        TouchEvent prev = events.get(idx - 1);
        TouchEvent curr = events.get(idx + 1);
        if (prev.pointers == null || curr.pointers == null) return 0f;
        if (prev.pointers.isEmpty() || curr.pointers.isEmpty()) return 0f;

        float dx = curr.pointers.get(0).x - prev.pointers.get(0).x;
        float dy = curr.pointers.get(0).y - prev.pointers.get(0).y;
        float dt = (curr.tMs - prev.tMs) / 1000f;
        if (dt < 0.001f) return 0f;
        return (float) Math.hypot(dx, dy) / dt;
    }

    private static float computeSamplesPerEventAvg(List<TouchEvent> events) {
        if (events.isEmpty()) return 0f;
        int total = 0;
        for (TouchEvent e : events) {
            if (e.historical != null) total += e.historical.size();
        }
        return (float) total / events.size();
    }

    private static DerivedFeatures emptyFeatures() {
        return new DerivedFeatures(0, 0, 0, 0, 0, 1f, "linear", 0, 0, 0);
    }
}
