package com.gesturedata.collector.data.model;

public enum QualityLevel {
    EXCELLENT(90, 100, "Excellent", 0xFF4CAF50),
    GOOD(70, 89, "Good", 0xFF8BC34A),
    FAIR(50, 69, "Fair", 0xFFFFC107),
    POOR(0, 49, "Poor", 0xFFF44336);

    public final int minScore;
    public final int maxScore;
    public final String label;
    public final int color;

    QualityLevel(int minScore, int maxScore, String label, int color) {
        this.minScore = minScore;
        this.maxScore = maxScore;
        this.label    = label;
        this.color    = color;
    }

    public static QualityLevel fromScore(int score) {
        for (QualityLevel level : values()) {
            if (score >= level.minScore && score <= level.maxScore) return level;
        }
        return POOR;
    }

    public boolean isAcceptable() {
        return this == EXCELLENT || this == GOOD || this == FAIR;
    }
}
