package com.gesturedata.collector.data.model;

import com.google.gson.annotations.SerializedName;
import java.util.List;

/**
 * One historical sub-sample within a MotionEvent.
 * Android's touch hardware samples at ~240Hz but delivers events at ~60Hz,
 * batching intermediate samples as historical data.
 */
public class HistoricalSample {

    /** Milliseconds relative to gesture start */
    @SerializedName("t_ms")
    public int tMs;

    /** One entry per active pointer at this historical moment */
    @SerializedName("pointers")
    public List<HistoricalPointer> pointers;

    public HistoricalSample() {}

    public HistoricalSample(int tMs, List<HistoricalPointer> pointers) {
        this.tMs      = tMs;
        this.pointers = pointers;
    }
}
