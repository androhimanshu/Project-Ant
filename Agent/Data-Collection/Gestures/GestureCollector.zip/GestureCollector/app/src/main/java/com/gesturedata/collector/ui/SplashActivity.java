package com.gesturedata.collector.ui;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import androidx.appcompat.app.AppCompatActivity;

import com.gesturedata.collector.R;
import com.gesturedata.collector.util.PreferencesManager;

public class SplashActivity extends AppCompatActivity {

    private static final long SPLASH_DELAY_MS = 1500;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            PreferencesManager prefs = PreferencesManager.getInstance(this);
            Intent next;
            if (!prefs.isOnboardingDone() || !prefs.isConsentGiven()) {
                next = new Intent(this, OnboardingActivity.class);
            } else {
                next = new Intent(this, HomeActivity.class);
            }
            startActivity(next);
            finish();
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        }, SPLASH_DELAY_MS);
    }
}
