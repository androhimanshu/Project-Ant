package com.gesturedata.collector.data.model;

/** All gesture types the app can record and the model is trained on. */
public enum GestureType {
    TAP("tap", "Tap", "tap"),
    DOUBLE_TAP("double_tap", "Double Tap", "tap"),
    LONG_PRESS("long_press", "Long Press", "tap"),
    SWIPE_UP("swipe_up", "Swipe Up", "up"),
    SWIPE_DOWN("swipe_down", "Swipe Down", "down"),
    SWIPE_LEFT("swipe_left", "Swipe Left", "left"),
    SWIPE_RIGHT("swipe_right", "Swipe Right", "right"),
    SWIPE_UP_LEFT("swipe_up_left", "Swipe Up-Left", "up_left"),
    SWIPE_UP_RIGHT("swipe_up_right", "Swipe Up-Right", "up_right"),
    SWIPE_DOWN_LEFT("swipe_down_left", "Swipe Down-Left", "down_left"),
    SWIPE_DOWN_RIGHT("swipe_down_right", "Swipe Down-Right", "down_right"),
    DRAG("drag", "Drag", null),
    PINCH_IN("pinch_in", "Pinch In", null),
    PINCH_OUT("pinch_out", "Pinch Out", null);

    /** JSON label — matches training pipeline column */
    public final String label;

    /** Human-readable display name */
    public final String displayName;

    /** Default direction string (null if not directional) */
    public final String defaultDirection;

    GestureType(String label, String displayName, String defaultDirection) {
        this.label            = label;
        this.displayName      = displayName;
        this.defaultDirection = defaultDirection;
    }

    public boolean isSwipe() {
        return name().startsWith("SWIPE");
    }

    public boolean isPinch() {
        return this == PINCH_IN || this == PINCH_OUT;
    }

    public boolean isTap() {
        return this == TAP || this == DOUBLE_TAP || this == LONG_PRESS;
    }

    public static GestureType fromLabel(String label) {
        for (GestureType t : values()) {
            if (t.label.equals(label)) return t;
        }
        return TAP;
    }
}
