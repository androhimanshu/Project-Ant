package com.gesturedata.collector.data.model;

/** User's hand/finger preferences — stored locally, sent with each gesture record. */
public class UserProfile {
    /** "right" or "left" */
    public String handedness = "right";
    /** "right_thumb", "right_index", "right_middle", "left_thumb", "left_index" */
    public String finger     = "right_index";
    /** "small", "normal", "large" — how the phone feels in hand */
    public String phoneFeel  = "normal";

    public UserProfile() {}

    public UserProfile(String handedness, String finger, String phoneFeel) {
        this.handedness = handedness;
        this.finger     = finger;
        this.phoneFeel  = phoneFeel;
    }
}
