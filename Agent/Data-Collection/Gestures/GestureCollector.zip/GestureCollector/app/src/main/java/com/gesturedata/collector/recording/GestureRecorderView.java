package com.gesturedata.collector.recording;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.RectF;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import com.gesturedata.collector.data.model.TouchEvent;
import com.gesturedata.collector.prompt.GesturePrompt;

import java.util.ArrayList;
import java.util.List;

/**
 * Custom View that:
 * 1. Captures every MotionEvent field (including historical sub-samples)
 * 2. Renders real-time visual feedback: contact ellipses, pressure heatmap, path trail
 * 3. Calls back with the complete event list when the gesture ends
 *
 * IMPORTANT: All Paint objects created in constructor — never in onDraw().
 * IMPORTANT: Never call event.recycle() — the framework owns the lifecycle.
 */
public class GestureRecorderView extends View {

    // ── Callback interface ─────────────────────────────────────────────────

    public interface GestureCompleteListener {
        /**
         * Called when ACTION_UP is received.
         * @param events              complete event list for the gesture
         * @param promptShownMs       ms between prompt shown and first touch
         * @param attemptNumber       1 = first try, 2+ = after retry
         */
        void onGestureComplete(List<TouchEvent> events,
                               int promptShownMs,
                               int attemptNumber);
    }

    // ── State ──────────────────────────────────────────────────────────────

    private GestureCompleteListener listener;
    private GesturePrompt           currentPrompt;
    private boolean                 isRecording = false;
    private long                    gestureStartTimeMs;
    private long                    promptShownAtMs;
    private int                     attemptNumber = 1;

    private final RawEventBuffer    buffer    = new RawEventBuffer();
    private final List<PointF>      pathPts   = new ArrayList<>();
    private final List<Ellipse>     ellipses  = new ArrayList<>();

    // ── Paint objects (created once) ──────────────────────────────────────

    private final Paint pathPaint      = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pathGlowPaint  = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ellipsePaint   = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint targetPaint    = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint startDotPaint  = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint endDotPaint    = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint labelPaint     = new Paint(Paint.ANTI_ALIAS_FLAG);

    private final Path drawPath = new Path();

    // ── Constructor ───────────────────────────────────────────────────────

    public GestureRecorderView(Context context) {
        super(context);
        init();
    }

    public GestureRecorderView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public GestureRecorderView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init();
    }

    private void init() {
        setFocusable(true);
        setClickable(true);

        float density = getResources().getDisplayMetrics().density;

        pathPaint.setColor(0xFF1565C0);
        pathPaint.setStyle(Paint.Style.STROKE);
        pathPaint.setStrokeWidth(3 * density);
        pathPaint.setStrokeCap(Paint.Cap.ROUND);
        pathPaint.setStrokeJoin(Paint.Join.ROUND);
        pathPaint.setAlpha(200);

        pathGlowPaint.setColor(0x441565C0);
        pathGlowPaint.setStyle(Paint.Style.STROKE);
        pathGlowPaint.setStrokeWidth(12 * density);
        pathGlowPaint.setStrokeCap(Paint.Cap.ROUND);
        pathGlowPaint.setStrokeJoin(Paint.Join.ROUND);
        pathGlowPaint.setMaskFilter(
                new android.graphics.BlurMaskFilter(8 * density,
                        android.graphics.BlurMaskFilter.Blur.NORMAL));

        ellipsePaint.setStyle(Paint.Style.FILL);
        ellipsePaint.setAlpha(140);

        targetPaint.setColor(0xFF4CAF50);
        targetPaint.setStyle(Paint.Style.STROKE);
        targetPaint.setStrokeWidth(2 * density);
        targetPaint.setPathEffect(new DashPathEffect(
                new float[]{10 * density, 6 * density}, 0));

        startDotPaint.setColor(0xFF4CAF50);
        startDotPaint.setStyle(Paint.Style.FILL);

        endDotPaint.setColor(0xFFF44336);
        endDotPaint.setStyle(Paint.Style.FILL);

        labelPaint.setColor(Color.WHITE);
        labelPaint.setTextSize(14 * density);
        labelPaint.setTextAlign(Paint.Align.CENTER);
    }

    // ── Public API ─────────────────────────────────────────────────────────

    public void setGestureCompleteListener(GestureCompleteListener l) {
        this.listener = l;
    }

    public void setPrompt(GesturePrompt prompt) {
        this.currentPrompt  = prompt;
        this.promptShownAtMs = SystemClock.uptimeMillis();
        resetVisuals();
        invalidate();
    }

    public void startRecording() {
        buffer.clear();
        resetVisuals();
        isRecording = true;
        invalidate();
    }

    public void resetForRetry() {
        attemptNumber++;
        startRecording();
    }

    public void resetSession() {
        attemptNumber = 1;
        startRecording();
    }

    // ── Touch handling ─────────────────────────────────────────────────────

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (!isRecording) return false;

        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                gestureStartTimeMs = event.getEventTime();
                buffer.clear();
                resetVisuals();
                break;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                // Extract BEFORE any other processing — historical data dies after return
                TouchEvent finalEvent = MotionEventExtractor.extract(
                        event, gestureStartTimeMs);
                buffer.add(finalEvent);
                isRecording = false;

                int promptShownMs = (int) (gestureStartTimeMs - promptShownAtMs);
                if (promptShownMs < 0) promptShownMs = 0;

                List<TouchEvent> completed = buffer.drain();
                if (listener != null) {
                    listener.onGestureComplete(completed, promptShownMs, attemptNumber);
                }
                // Keep visuals for result display
                invalidate();
                return true;
        }

        // Extract for MOVE and POINTER_DOWN/UP too
        TouchEvent touchEvent = MotionEventExtractor.extract(event, gestureStartTimeMs);
        buffer.add(touchEvent);

        // Update visual state for primary pointer
        if (event.getPointerCount() > 0) {
            float x = event.getX();
            float y = event.getY();
            pathPts.add(new PointF(x, y));

            ellipses.add(new Ellipse(
                    x, y,
                    event.getTouchMajor(),
                    event.getTouchMinor(),
                    event.getOrientation(),
                    event.getPressure()));

            // Keep last 60 ellipses to avoid clutter
            if (ellipses.size() > 60) ellipses.remove(0);
        }

        invalidate();
        return true;
    }

    // ── Drawing ────────────────────────────────────────────────────────────

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawColor(0xFF1A1A2E); // dark navy background

        drawTargetZone(canvas);
        drawStartEndHints(canvas);
        drawGlowPath(canvas);
        drawPath(canvas);
        drawContactEllipses(canvas);
        drawInstruction(canvas);
    }

    private void drawTargetZone(Canvas canvas) {
        if (currentPrompt == null || currentPrompt.targetZone == null) return;
        canvas.drawRoundRect(currentPrompt.targetZone, 12, 12, targetPaint);
    }

    private void drawStartEndHints(Canvas canvas) {
        if (currentPrompt == null) return;
        float density = getResources().getDisplayMetrics().density;
        float r = 10 * density;

        if (currentPrompt.startHint != null) {
            canvas.drawCircle(currentPrompt.startHint.x,
                              currentPrompt.startHint.y,
                              r, startDotPaint);
        }
        if (currentPrompt.endHint != null) {
            canvas.drawCircle(currentPrompt.endHint.x,
                              currentPrompt.endHint.y,
                              r, endDotPaint);
        }
    }

    private void drawGlowPath(Canvas canvas) {
        if (pathPts.size() < 2) return;
        buildPath();
        canvas.drawPath(drawPath, pathGlowPaint);
    }

    private void drawPath(Canvas canvas) {
        if (pathPts.size() < 2) return;
        buildPath();
        canvas.drawPath(drawPath, pathPaint);
    }

    private void buildPath() {
        drawPath.reset();
        drawPath.moveTo(pathPts.get(0).x, pathPts.get(0).y);
        for (int i = 1; i < pathPts.size(); i++) {
            drawPath.lineTo(pathPts.get(i).x, pathPts.get(i).y);
        }
    }

    private void drawContactEllipses(Canvas canvas) {
        int size = ellipses.size();
        for (int i = 0; i < size; i++) {
            Ellipse el = ellipses.get(i);
            // Fade older ellipses
            int alpha = (int) (80 + 120 * ((float) i / Math.max(1, size - 1)));

            // Color: blue (low pressure) → red (high pressure)
            int r = (int) (255 * el.pressure);
            int b = (int) (255 * (1f - el.pressure));
            ellipsePaint.setColor(Color.argb(alpha, r, 0, b));

            canvas.save();
            canvas.translate(el.x, el.y);
            canvas.rotate((float) Math.toDegrees(el.orientation));
            float hw = el.touchMajor / 2f;
            float hh = el.touchMinor / 2f;
            if (hw < 1f) hw = 1f;
            if (hh < 1f) hh = 1f;
            canvas.drawOval(new RectF(-hw, -hh, hw, hh), ellipsePaint);
            canvas.restore();
        }
    }

    private void drawInstruction(Canvas canvas) {
        if (currentPrompt == null || isRecording) return;
        if (!pathPts.isEmpty()) return; // hide once gesture started
        float cx = getWidth() / 2f;
        float cy = getHeight() * 0.85f;
        canvas.drawText(currentPrompt.instruction, cx, cy, labelPaint);
    }

    // ── Helpers ────────────────────────────────────────────────────────────

    private void resetVisuals() {
        pathPts.clear();
        ellipses.clear();
        drawPath.reset();
    }

    // ── Inner types ───────────────────────────────────────────────────────

    private static class Ellipse {
        float x, y, touchMajor, touchMinor, orientation, pressure;
        Ellipse(float x, float y, float touchMajor, float touchMinor,
                float orientation, float pressure) {
            this.x           = x;
            this.y           = y;
            this.touchMajor  = touchMajor;
            this.touchMinor  = touchMinor;
            this.orientation = orientation;
            this.pressure    = pressure;
        }
    }
}
