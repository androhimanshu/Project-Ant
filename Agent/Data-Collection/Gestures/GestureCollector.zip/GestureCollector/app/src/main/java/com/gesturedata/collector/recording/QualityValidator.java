package com.gesturedata.collector.recording;

import com.gesturedata.collector.data.model.GestureType;
import com.gesturedata.collector.data.model.PointerSample;
import com.gesturedata.collector.data.model.QualityLevel;
import com.gesturedata.collector.data.model.TouchEvent;
import com.gesturedata.collector.prompt.GesturePrompt;

import java.util.List;

/**
 * Validates a recorded gesture and produces a quality score 0–100.
 * Hard rejects are scored 0 with a reason string.
 * Soft deductions reduce from 100 for lesser issues.
 */
public class QualityValidator {

    public static class ValidationResult {
        public final int          score;
        public final QualityLevel level;
        public final String       rejectReason; // null if not hard-rejected

        public ValidationResult(int score, String rejectReason) {
            this.score        = score;
            this.level        = QualityLevel.fromScore(score);
            this.rejectReason = rejectReason;
        }

        public boolean isAcceptable() {
            return rejectReason == null && level.isAcceptable();
        }
    }

    private QualityValidator() {}

    public static ValidationResult validate(List<TouchEvent> events,
                                            GesturePrompt prompt) {
        if (events == null || events.isEmpty()) {
            return new ValidationResult(0, "No events captured");
        }

        // ── Find start / end events ────────────────────────────────────────
        TouchEvent downEvent = null;
        TouchEvent upEvent   = null;
        int maxPointerCount  = 0;
        float maxPressure    = 0f;

        for (TouchEvent e : events) {
            if ("DOWN".equals(e.action) && downEvent == null) downEvent = e;
            if ("UP".equals(e.action))   upEvent = e;
            if (e.pointers != null) {
                if (e.pointers.size() > maxPointerCount)
                    maxPointerCount = e.pointers.size();
                for (PointerSample p : e.pointers) {
                    if (p.pressure > maxPressure) maxPressure = p.pressure;
                }
            }
        }

        if (downEvent == null) return new ValidationResult(0, "No touch start detected");
        if (upEvent   == null) return new ValidationResult(0, "No touch end detected");

        int durationMs = upEvent.tMs - downEvent.tMs;

        // ── Hard rejects ───────────────────────────────────────────────────

        if (events.size() < 3)
            return new ValidationResult(0, "Too few events (< 3)");

        if (durationMs < 50)
            return new ValidationResult(0, "Too fast — likely accidental touch");

        if (durationMs > 5000)
            return new ValidationResult(0, "Too slow — pause detected mid-gesture");

        if (maxPressure < 0.05f)
            return new ValidationResult(0, "No pressure detected — sensor issue?");

        // Check non-finger tool type
        for (TouchEvent e : events) {
            if (e.pointers != null) {
                for (PointerSample p : e.pointers) {
                    // TOOL_TYPE_FINGER = 1
                    if (p.toolType != 0 && p.toolType != 1) {
                        return new ValidationResult(0, "Non-finger input detected (stylus/mouse)");
                    }
                }
            }
        }

        // Gesture-specific hard rejects
        if (prompt != null) {
            float displacement = computeDisplacement(events);

            if (prompt.gestureType.isTap() && displacement > 60f) {
                return new ValidationResult(0, "Too much movement for a tap gesture");
            }

            if (prompt.gestureType.isSwipe() && displacement < 100f) {
                return new ValidationResult(0, "Swipe distance too short (< 100px)");
            }

            if (prompt.gestureType.isPinch() && maxPointerCount < 2) {
                return new ValidationResult(0, "Pinch requires two fingers");
            }
        }

        // ── Soft deductions ────────────────────────────────────────────────
        int score = 100;
        float samplesPerEventAvg = computeSamplesPerEventAvg(events);

        // Low historical sample density → velocity tracking will be degraded
        if (samplesPerEventAvg < 1.5f) score -= 15;

        // Excessive jitter
        float jitter = computeJitter(events);
        if (jitter > 8.0f) score -= 10;

        // Low pressure (might be incomplete contact data)
        if (maxPressure < 0.2f) score -= 10;

        // Swipe direction mismatch
        if (prompt != null && prompt.gestureType.isSwipe()) {
            if (!isDirectionCorrect(events, prompt.gestureType)) score -= 20;
            float linearity = computePathLinearity(events);
            if (linearity < 0.7f) score -= 10;
        }

        score = Math.max(0, score);
        return new ValidationResult(score, null);
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    private static float computeDisplacement(List<TouchEvent> events) {
        float sx = Float.NaN, sy = Float.NaN;
        float maxD = 0f;
        for (TouchEvent e : events) {
            if (e.pointers == null || e.pointers.isEmpty()) continue;
            float x = e.pointers.get(0).x;
            float y = e.pointers.get(0).y;
            if (Float.isNaN(sx)) { sx = x; sy = y; continue; }
            float d = (float) Math.hypot(x - sx, y - sy);
            if (d > maxD) maxD = d;
        }
        return maxD;
    }

    private static float computeSamplesPerEventAvg(List<TouchEvent> events) {
        if (events.isEmpty()) return 0f;
        int total = 0;
        for (TouchEvent e : events) {
            if (e.historical != null) total += e.historical.size();
        }
        return (float) total / events.size();
    }

    private static float computeJitter(List<TouchEvent> events) {
        // Simplified version — just measure average deviation from mean position
        int n = 0;
        double sumX = 0, sumY = 0;
        for (TouchEvent e : events) {
            if ("MOVE".equals(e.action) && e.pointers != null && !e.pointers.isEmpty()) {
                sumX += e.pointers.get(0).x;
                sumY += e.pointers.get(0).y;
                n++;
            }
        }
        if (n < 2) return 0f;
        double meanX = sumX / n, meanY = sumY / n;
        double sumSq = 0;
        for (TouchEvent e : events) {
            if ("MOVE".equals(e.action) && e.pointers != null && !e.pointers.isEmpty()) {
                // perpendicular deviation from start→end line handled in DerivedFeatureComputer
                // here we just check gross movement noise
                double dx = e.pointers.get(0).x - meanX;
                double dy = e.pointers.get(0).y - meanY;
                sumSq += dx*dx + dy*dy;
            }
        }
        return (float) Math.sqrt(sumSq / n);
    }

    private static float computePathLinearity(List<TouchEvent> events) {
        float sx = Float.NaN, sy = Float.NaN, ex = 0, ey = 0;
        double actual = 0;
        float px = Float.NaN, py = Float.NaN;

        for (TouchEvent e : events) {
            if (e.pointers == null || e.pointers.isEmpty()) continue;
            float x = e.pointers.get(0).x, y = e.pointers.get(0).y;
            if (Float.isNaN(sx)) { sx = x; sy = y; px = x; py = y; continue; }
            actual += Math.hypot(x - px, y - py);
            ex = x; ey = y; px = x; py = y;
        }
        double straight = Math.hypot(ex - sx, ey - sy);
        if (actual < 1f) return 1f;
        return (float) Math.min(1.0, straight / actual);
    }

    private static boolean isDirectionCorrect(List<TouchEvent> events,
                                              GestureType type) {
        float sx = Float.NaN, sy = Float.NaN;
        float ex = 0, ey = 0;
        for (TouchEvent e : events) {
            if (e.pointers == null || e.pointers.isEmpty()) continue;
            float x = e.pointers.get(0).x, y = e.pointers.get(0).y;
            if (Float.isNaN(sx)) { sx = x; sy = y; }
            ex = x; ey = y;
        }
        float dx = ex - sx, dy = ey - sy;

        switch (type) {
            case SWIPE_UP:         return dy < -50;
            case SWIPE_DOWN:       return dy > 50;
            case SWIPE_LEFT:       return dx < -50;
            case SWIPE_RIGHT:      return dx > 50;
            case SWIPE_UP_LEFT:    return dx < -30 && dy < -30;
            case SWIPE_UP_RIGHT:   return dx > 30  && dy < -30;
            case SWIPE_DOWN_LEFT:  return dx < -30 && dy > 30;
            case SWIPE_DOWN_RIGHT: return dx > 30  && dy > 30;
            default:               return true;
        }
    }
}
