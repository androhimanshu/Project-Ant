package com.gesturedata.collector.data.model;

import com.google.gson.annotations.SerializedName;
import java.util.List;

/**
 * Complete capture of one Android MotionEvent.
 * Contains all active pointers + all event-level metadata + historical sub-samples.
 * This is the atomic unit of the touch time-series the model trains on.
 */
public class TouchEvent {

    /** Milliseconds elapsed since gesture ACTION_DOWN */
    @SerializedName("t_ms")
    public int tMs;

    /** "DOWN", "MOVE", "UP", "CANCEL", "POINTER_DOWN", "POINTER_UP" */
    @SerializedName("action")
    public String action;

    /**
     * All active pointers at this event.
     * Size == 1 for tap/swipe, Size == 2 for pinch.
     */
    @SerializedName("pointers")
    public List<PointerSample> pointers;

    // ── Event-level metadata ──────────────────────────────────────────────

    /** Which mouse/stylus buttons are pressed (0 for finger) */
    @SerializedName("button_state")
    public int buttonState;

    /** Keyboard modifier state (Ctrl/Shift/Alt) — usually 0 on phone */
    @SerializedName("meta_state")
    public int metaState;

    /** Screen edge flags — non-zero for bezel-edge gestures */
    @SerializedName("edge_flags")
    public int edgeFlags;

    /** MotionEvent flags bitmap */
    @SerializedName("flags")
    public int flags;

    /** Vertical scroll axis value (from scroll wheel / trackpad) */
    @SerializedName("vscroll")
    public float vscroll;

    /** Horizontal scroll axis value */
    @SerializedName("hscroll")
    public float hscroll;

    /**
     * Historical sub-samples batched inside this MotionEvent.
     * Critical for correct velocity tracking — do not omit.
     */
    @SerializedName("historical")
    public List<HistoricalSample> historical;

    public TouchEvent() {}

    public TouchEvent(int tMs, String action,
                      List<PointerSample> pointers,
                      int buttonState, int metaState,
                      int edgeFlags, int flags,
                      float vscroll, float hscroll,
                      List<HistoricalSample> historical) {
        this.tMs         = tMs;
        this.action      = action;
        this.pointers    = pointers;
        this.buttonState = buttonState;
        this.metaState   = metaState;
        this.edgeFlags   = edgeFlags;
        this.flags       = flags;
        this.vscroll     = vscroll;
        this.hscroll     = hscroll;
        this.historical  = historical;
    }
}
