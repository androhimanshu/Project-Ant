package com.gesturedata.collector.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewFlipper;

import androidx.appcompat.app.AppCompatActivity;

import com.gesturedata.collector.R;
import com.gesturedata.collector.data.model.UserProfile;
import com.gesturedata.collector.util.PreferencesManager;

public class OnboardingActivity extends AppCompatActivity {

    private ViewFlipper viewFlipper;
    private Button      btnNext;
    private Button      btnBack;
    private TextView    tvPageIndicator;

    private int currentPage = 0;
    private static final int TOTAL_PAGES = 4;

    // Page 4 — profile widgets
    private RadioGroup  rgHandedness;
    private RadioGroup  rgFinger;
    private RadioGroup  rgPhoneFeel;
    private CheckBox    cbConsent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_onboarding);

        viewFlipper    = findViewById(R.id.viewFlipper);
        btnNext        = findViewById(R.id.btnNext);
        btnBack        = findViewById(R.id.btnBack);
        tvPageIndicator= findViewById(R.id.tvPageIndicator);

        // Profile page widgets
        rgHandedness = findViewById(R.id.rgHandedness);
        rgFinger     = findViewById(R.id.rgFinger);
        rgPhoneFeel  = findViewById(R.id.rgPhoneFeel);
        cbConsent    = findViewById(R.id.cbConsent);

        updatePageState();

        btnNext.setOnClickListener(v -> {
            if (currentPage == TOTAL_PAGES - 1) {
                if (!validateProfilePage()) return;
                saveProfileAndProceed();
            } else {
                currentPage++;
                viewFlipper.showNext();
                updatePageState();
            }
        });

        btnBack.setOnClickListener(v -> {
            if (currentPage > 0) {
                currentPage--;
                viewFlipper.showPrevious();
                updatePageState();
            }
        });
    }

    private void updatePageState() {
        tvPageIndicator.setText((currentPage + 1) + " / " + TOTAL_PAGES);
        btnBack.setVisibility(currentPage == 0 ? View.INVISIBLE : View.VISIBLE);
        btnNext.setText(currentPage == TOTAL_PAGES - 1 ? "Get Started" : "Next →");
    }

    private boolean validateProfilePage() {
        if (!cbConsent.isChecked()) {
            Toast.makeText(this,
                    "Please read and accept the data consent to continue.",
                    Toast.LENGTH_LONG).show();
            return false;
        }
        if (rgHandedness.getCheckedRadioButtonId() == -1) {
            Toast.makeText(this, "Please select your dominant hand.", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private void saveProfileAndProceed() {
        UserProfile profile = new UserProfile();

        // Handedness
        int handId = rgHandedness.getCheckedRadioButtonId();
        RadioButton rbHand = findViewById(handId);
        profile.handedness = rbHand != null
                ? (rbHand.getText().toString().toLowerCase().contains("right") ? "right" : "left")
                : "right";

        // Finger
        int fingerId = rgFinger.getCheckedRadioButtonId();
        if (fingerId != -1) {
            RadioButton rbFinger = findViewById(fingerId);
            String fingerText = rbFinger != null ? rbFinger.getText().toString().toLowerCase() : "";
            if (fingerText.contains("thumb"))       profile.finger = profile.handedness + "_thumb";
            else if (fingerText.contains("middle")) profile.finger = profile.handedness + "_middle";
            else                                    profile.finger = profile.handedness + "_index";
        }

        // Phone feel
        int feelId = rgPhoneFeel.getCheckedRadioButtonId();
        if (feelId != -1) {
            RadioButton rbFeel = findViewById(feelId);
            String feelText = rbFeel != null ? rbFeel.getText().toString().toLowerCase() : "normal";
            if (feelText.contains("small"))       profile.phoneFeel = "small";
            else if (feelText.contains("large"))  profile.phoneFeel = "large";
            else                                  profile.phoneFeel = "normal";
        }

        PreferencesManager prefs = PreferencesManager.getInstance(this);
        prefs.saveUserProfile(profile);
        prefs.setConsentGiven(true);
        prefs.setOnboardingDone(true);

        startActivity(new Intent(this, HomeActivity.class));
        finish();
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }
}
