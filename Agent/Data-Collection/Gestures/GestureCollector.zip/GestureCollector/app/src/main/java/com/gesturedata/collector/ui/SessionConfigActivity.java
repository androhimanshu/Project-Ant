package com.gesturedata.collector.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.gesturedata.collector.R;
import com.gesturedata.collector.data.model.GestureType;
import com.gesturedata.collector.data.model.SessionConfig;
import com.gesturedata.collector.data.model.SpeedCue;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;

import java.util.ArrayList;
import java.util.List;

public class SessionConfigActivity extends AppCompatActivity {

    public static final String EXTRA_SESSION_CONFIG = "session_config_json";

    private ChipGroup  chipGroupTypes;
    private RadioGroup rgGesturesPerType;
    private RadioGroup rgSpeedCue;
    private RadioGroup rgSessionPreset;
    private Button     btnBegin;
    private TextView   tvTotalLabel;

    // quick preset buttons
    private Button btnPresetQuick;
    private Button btnPresetStandard;
    private Button btnPresetDeep;

    private final List<Chip> typeChips = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_session_config);

        chipGroupTypes    = findViewById(R.id.chipGroupTypes);
        rgGesturesPerType = findViewById(R.id.rgGesturesPerType);
        rgSpeedCue        = findViewById(R.id.rgSpeedCue);
        btnBegin          = findViewById(R.id.btnBegin);
        tvTotalLabel      = findViewById(R.id.tvTotalLabel);
        btnPresetQuick    = findViewById(R.id.btnPresetQuick);
        btnPresetStandard = findViewById(R.id.btnPresetStandard);
        btnPresetDeep     = findViewById(R.id.btnPresetDeep);

        buildGestureTypeChips();

        // Default selection — standard
        applyPreset(SessionConfig.standard());

        btnPresetQuick.setOnClickListener(v -> applyPreset(SessionConfig.quick()));
        btnPresetStandard.setOnClickListener(v -> applyPreset(SessionConfig.standard()));
        btnPresetDeep.setOnClickListener(v -> applyPreset(SessionConfig.deep()));

        // Update total label whenever selections change
        chipGroupTypes.setOnCheckedStateChangeListener((group, ids) -> updateTotalLabel());
        rgGesturesPerType.setOnCheckedChangeListener((g, id) -> updateTotalLabel());

        btnBegin.setOnClickListener(v -> {
            SessionConfig config = buildConfig();
            if (config.selectedTypes.isEmpty()) {
                Toast.makeText(this, "Select at least one gesture type", Toast.LENGTH_SHORT).show();
                return;
            }
            // Serialize config via Gson and pass to GesturePromptActivity
            com.google.gson.Gson gson = new com.google.gson.Gson();
            String json = gson.toJson(config);
            Intent intent = new Intent(this, GesturePromptActivity.class);
            intent.putExtra(EXTRA_SESSION_CONFIG, json);
            startActivity(intent);
        });
    }

    private void buildGestureTypeChips() {
        for (GestureType type : GestureType.values()) {
            Chip chip = new Chip(this);
            chip.setText(type.displayName);
            chip.setTag(type);
            chip.setCheckable(true);
            chip.setCheckedIconVisible(true);
            chipGroupTypes.addView(chip);
            typeChips.add(chip);
        }
    }

    private void applyPreset(SessionConfig preset) {
        // Deselect all chips
        for (Chip c : typeChips) c.setChecked(false);

        // Select preset types
        for (GestureType t : preset.selectedTypes) {
            for (Chip c : typeChips) {
                if (c.getTag() == t) { c.setChecked(true); break; }
            }
        }

        // Set gestures per type
        int gpTypeId;
        switch (preset.gesturesPerType) {
            case 5:  gpTypeId = R.id.rb5;  break;
            case 25: gpTypeId = R.id.rb25; break;
            case 50: gpTypeId = R.id.rb50; break;
            default: gpTypeId = R.id.rb10; break;
        }
        rgGesturesPerType.check(gpTypeId);

        // Set speed
        int speedId;
        switch (preset.speedCue) {
            case SLOW: speedId = R.id.rbSlow; break;
            case FAST: speedId = R.id.rbFast; break;
            default:   speedId = R.id.rbNormal; break;
        }
        rgSpeedCue.check(speedId);

        updateTotalLabel();
    }

    private SessionConfig buildConfig() {
        SessionConfig config = new SessionConfig();

        for (Chip c : typeChips) {
            if (c.isChecked()) config.selectedTypes.add((GestureType) c.getTag());
        }

        int gpId = rgGesturesPerType.getCheckedRadioButtonId();
        if      (gpId == R.id.rb5)  config.gesturesPerType = 5;
        else if (gpId == R.id.rb25) config.gesturesPerType = 25;
        else if (gpId == R.id.rb50) config.gesturesPerType = 50;
        else                        config.gesturesPerType = 10;

        int spId = rgSpeedCue.getCheckedRadioButtonId();
        if      (spId == R.id.rbSlow) config.speedCue = SpeedCue.SLOW;
        else if (spId == R.id.rbFast) config.speedCue = SpeedCue.FAST;
        else                          config.speedCue = SpeedCue.NORMAL;

        return config;
    }

    private void updateTotalLabel() {
        int checkedCount = 0;
        for (Chip c : typeChips) { if (c.isChecked()) checkedCount++; }

        int gpId = rgGesturesPerType.getCheckedRadioButtonId();
        int perType;
        if      (gpId == R.id.rb5)  perType = 5;
        else if (gpId == R.id.rb25) perType = 25;
        else if (gpId == R.id.rb50) perType = 50;
        else                        perType = 10;

        int total = checkedCount * perType;
        tvTotalLabel.setText("Total: " + total + " gestures");
    }
}
