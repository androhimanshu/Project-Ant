package com.gesturedata.collector.upload;

import android.content.Context;

import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import java.util.concurrent.TimeUnit;

public class UploadScheduler {

    private static final String WORK_NAME = "gesture_upload_periodic";

    public static void schedule(Context context) {
        Constraints constraints = new Constraints.Builder()
                .setRequiredNetworkType(NetworkType.UNMETERED) // WiFi only
                .build();

        PeriodicWorkRequest request =
                new PeriodicWorkRequest.Builder(UploadWorker.class, 6, TimeUnit.HOURS)
                        .setConstraints(constraints)
                        .build();

        WorkManager.getInstance(context)
                .enqueueUniquePeriodicWork(
                        WORK_NAME,
                        ExistingPeriodicWorkPolicy.KEEP,
                        request);
    }

    public static void scheduleImmediate(Context context) {
        androidx.work.OneTimeWorkRequest request =
                new androidx.work.OneTimeWorkRequest.Builder(UploadWorker.class)
                        .build();
        WorkManager.getInstance(context).enqueue(request);
    }
}
