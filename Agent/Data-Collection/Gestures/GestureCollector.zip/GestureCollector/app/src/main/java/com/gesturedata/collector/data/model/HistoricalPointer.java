package com.gesturedata.collector.data.model;

import com.google.gson.annotations.SerializedName;

/**
 * One pointer's data within a historical sub-sample.
 * Android batches 2–4 sub-samples per MotionEvent at high touch rates.
 * Without these, fling/scroll velocity tracking breaks.
 */
public class HistoricalPointer {

    @SerializedName("pointer_id")
    public int pointerId;

    @SerializedName("x")
    public float x;

    @SerializedName("y")
    public float y;

    @SerializedName("pressure")
    public float pressure;

    @SerializedName("touch_major")
    public float touchMajor;

    @SerializedName("touch_minor")
    public float touchMinor;

    public HistoricalPointer() {}

    public HistoricalPointer(int pointerId, float x, float y,
                             float pressure, float touchMajor, float touchMinor) {
        this.pointerId  = pointerId;
        this.x          = x;
        this.y          = y;
        this.pressure   = pressure;
        this.touchMajor = touchMajor;
        this.touchMinor = touchMinor;
    }
}
