package com.gesturedata.collector.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.gesturedata.collector.R;
import com.gesturedata.collector.upload.UploadScheduler;
import com.gesturedata.collector.viewmodel.HomeViewModel;

public class HomeActivity extends AppCompatActivity {

    private HomeViewModel viewModel;

    // Stat views
    private TextView tvTotalGestures;
    private TextView tvTodayGestures;
    private TextView tvPendingUpload;
    private TextView tvStreak;
    private TextView tvUploadBadge;

    // Buttons
    private Button btnStartSession;
    private Button btnUploadNow;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        viewModel = new ViewModelProvider(this).get(HomeViewModel.class);

        tvTotalGestures = findViewById(R.id.tvTotalGestures);
        tvTodayGestures = findViewById(R.id.tvTodayGestures);
        tvPendingUpload = findViewById(R.id.tvPendingUpload);
        tvStreak        = findViewById(R.id.tvStreak);
        tvUploadBadge   = findViewById(R.id.tvUploadBadge);
        btnStartSession = findViewById(R.id.btnStartSession);
        btnUploadNow    = findViewById(R.id.btnUploadNow);

        viewModel.getStats().observe(this, stats -> {
            tvTotalGestures.setText(String.valueOf(stats.totalGestures));
            tvTodayGestures.setText(String.valueOf(stats.todayGestures));
            tvPendingUpload.setText(stats.pendingUpload + " pending");
            tvStreak.setText(stats.streak + " day streak 🔥");

            if (stats.pendingUpload > 0) {
                tvUploadBadge.setVisibility(View.VISIBLE);
                tvUploadBadge.setText(String.valueOf(stats.pendingUpload));
            } else {
                tvUploadBadge.setVisibility(View.GONE);
            }
        });

        btnStartSession.setOnClickListener(v ->
                startActivity(new Intent(this, SessionConfigActivity.class)));

        btnUploadNow.setOnClickListener(v -> {
            UploadScheduler.scheduleImmediate(this);
            startActivity(new Intent(this, UploadActivity.class));
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        viewModel.refreshStats();
    }
}
