package com.gesturedata.collector.prompt;

import android.graphics.PointF;
import android.graphics.RectF;
import com.gesturedata.collector.data.model.GestureType;
import com.gesturedata.collector.data.model.SpeedCue;

import java.util.Random;

/**
 * Generates randomized gesture prompts for each slot.
 * Varies: target position, target size, swipe length.
 * Ensures start hint never lands within 80px of screen edges.
 */
public class GesturePromptGenerator {

    private final int    screenWidth;
    private final int    screenHeight;
    private final Random rng = new Random();

    private static final int   EDGE_MARGIN   = 80;
    private static final int[] TAP_SIZES_DP  = {32, 48, 64, 96};
    private static final int[] SWIPE_LENGTHS = {200, 350, 500, 700, 900};

    public GesturePromptGenerator(int screenWidth, int screenHeight) {
        this.screenWidth  = screenWidth;
        this.screenHeight = screenHeight;
    }

    public GesturePrompt generate(GestureType type, SpeedCue speedCue) {
        switch (type) {
            case TAP:         return buildTap(type, speedCue, "single");
            case DOUBLE_TAP:  return buildTap(type, speedCue, "double");
            case LONG_PRESS:  return buildLongPress(speedCue);
            case SWIPE_UP:    return buildDirectionalSwipe(type, speedCue,  0, -1);
            case SWIPE_DOWN:  return buildDirectionalSwipe(type, speedCue,  0,  1);
            case SWIPE_LEFT:  return buildDirectionalSwipe(type, speedCue, -1,  0);
            case SWIPE_RIGHT: return buildDirectionalSwipe(type, speedCue,  1,  0);
            case SWIPE_UP_LEFT:    return buildDirectionalSwipe(type, speedCue, -1, -1);
            case SWIPE_UP_RIGHT:   return buildDirectionalSwipe(type, speedCue,  1, -1);
            case SWIPE_DOWN_LEFT:  return buildDirectionalSwipe(type, speedCue, -1,  1);
            case SWIPE_DOWN_RIGHT: return buildDirectionalSwipe(type, speedCue,  1,  1);
            case DRAG:        return buildDrag(speedCue);
            case PINCH_IN:    return buildPinch(type, speedCue);
            case PINCH_OUT:   return buildPinch(type, speedCue);
            default:          return buildTap(type, speedCue, "single");
        }
    }

    private GesturePrompt buildTap(GestureType type, SpeedCue speedCue, String sub) {
        int sizeDp  = TAP_SIZES_DP[rng.nextInt(TAP_SIZES_DP.length)];
        float sizePx = dpToPx(sizeDp);

        float cx = randomX(EDGE_MARGIN + sizePx, screenWidth  - EDGE_MARGIN - sizePx);
        float cy = randomY(EDGE_MARGIN + sizePx, screenHeight - EDGE_MARGIN - sizePx);

        RectF zone = new RectF(cx - sizePx/2, cy - sizePx/2,
                               cx + sizePx/2, cy + sizePx/2);
        return new GesturePrompt(type, speedCue, zone,
                new PointF(cx, cy), null,
                "Tap the circle " + speedCue.instruction.toLowerCase(),
                "button", (int) sizePx);
    }

    private GesturePrompt buildLongPress(SpeedCue speedCue) {
        float sizePx = dpToPx(64);
        float cx = randomX(EDGE_MARGIN + sizePx, screenWidth  - EDGE_MARGIN - sizePx);
        float cy = randomY(EDGE_MARGIN + sizePx, screenHeight - EDGE_MARGIN - sizePx);
        RectF zone = new RectF(cx - sizePx/2, cy - sizePx/2,
                               cx + sizePx/2, cy + sizePx/2);
        return new GesturePrompt(GestureType.LONG_PRESS, speedCue, zone,
                new PointF(cx, cy), null,
                "Press and hold for 1 second",
                "button", (int) sizePx);
    }

    private GesturePrompt buildDirectionalSwipe(GestureType type, SpeedCue speedCue,
                                                int dx, int dy) {
        // Normalize diagonal direction
        float len    = (float) Math.sqrt(dx * dx + dy * dy);
        float ndx    = dx / len;
        float ndy    = dy / len;
        int swipeLen = SWIPE_LENGTHS[rng.nextInt(SWIPE_LENGTHS.length)];

        // Place start so that end stays within screen
        float minSx = EDGE_MARGIN + (ndx < 0 ? -ndx * swipeLen : 0);
        float maxSx = screenWidth  - EDGE_MARGIN - (ndx > 0 ? ndx * swipeLen : 0);
        float minSy = EDGE_MARGIN + (ndy < 0 ? -ndy * swipeLen : 0);
        float maxSy = screenHeight - EDGE_MARGIN - (ndy > 0 ? ndy * swipeLen : 0);

        if (minSx > maxSx) { float t = minSx; minSx = maxSx; maxSx = t; }
        if (minSy > maxSy) { float t = minSy; minSy = maxSy; maxSy = t; }

        float sx = randomX(minSx, maxSx);
        float sy = randomY(minSy, maxSy);
        float ex = sx + ndx * swipeLen;
        float ey = sy + ndy * swipeLen;

        RectF zone = new RectF(Math.min(sx, ex) - 40, Math.min(sy, ey) - 40,
                               Math.max(sx, ex) + 40, Math.max(sy, ey) + 40);

        String dirName = type.displayName.replace("Swipe ", "").toLowerCase();
        String instr = "Swipe " + dirName + " — " + speedCue.instruction.toLowerCase();

        return new GesturePrompt(type, speedCue, zone,
                new PointF(sx, sy), new PointF(ex, ey),
                instr, "scroll_area", swipeLen);
    }

    private GesturePrompt buildDrag(SpeedCue speedCue) {
        float sx = randomX(EDGE_MARGIN + 80, screenWidth  / 2f);
        float sy = randomY(EDGE_MARGIN + 80, screenHeight / 3f);
        float ex = randomX(screenWidth / 2f, screenWidth  - EDGE_MARGIN - 80);
        float ey = randomY(screenHeight * 2f/3f, screenHeight - EDGE_MARGIN - 80);

        RectF zone = new RectF(Math.min(sx, ex) - 40, Math.min(sy, ey) - 40,
                               Math.max(sx, ex) + 40, Math.max(sy, ey) + 40);
        return new GesturePrompt(GestureType.DRAG, speedCue, zone,
                new PointF(sx, sy), new PointF(ex, ey),
                "Drag from the green dot to the red dot",
                "drag_handle", (int) Math.hypot(ex - sx, ey - sy));
    }

    private GesturePrompt buildPinch(GestureType type, SpeedCue speedCue) {
        float cx = screenWidth  / 2f;
        float cy = screenHeight / 2f;
        float spread = 300;
        RectF zone = new RectF(cx - spread, cy - spread, cx + spread, cy + spread);
        boolean isIn = type == GestureType.PINCH_IN;
        String instr = isIn
                ? "Pinch in with two fingers (spread → close)"
                : "Pinch out with two fingers (close → spread)";
        return new GesturePrompt(type, speedCue, zone,
                new PointF(cx - (isIn ? spread : 80), cy),
                new PointF(cx + (isIn ? spread : 80), cy),
                instr, "image", (int) spread * 2);
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    private float randomX(float min, float max) {
        if (min >= max) return (min + max) / 2f;
        return min + rng.nextFloat() * (max - min);
    }

    private float randomY(float min, float max) {
        if (min >= max) return (min + max) / 2f;
        return min + rng.nextFloat() * (max - min);
    }

    private float dpToPx(int dp) {
        return dp * (screenWidth / 360f); // approximate density scaling
    }
}
