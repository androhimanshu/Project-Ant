package com.gesturedata.collector.recording;

import android.view.MotionEvent;
import com.gesturedata.collector.data.model.HistoricalPointer;
import com.gesturedata.collector.data.model.HistoricalSample;
import com.gesturedata.collector.data.model.PointerSample;
import com.gesturedata.collector.data.model.TouchEvent;

import java.util.ArrayList;
import java.util.List;

/**
 * Converts a raw Android MotionEvent into our TouchEvent data model.
 * Extracts every available field including historical sub-samples.
 *
 * CRITICAL NOTES:
 * - Must be called synchronously inside onTouchEvent() — historical data
 *   is only valid during the callback and cannot be read later.
 * - getRawX/getRawY are only available for pointer index 0 on Android.
 *   For other pointers we fall back to view-local coordinates.
 * - Use SystemClock.uptimeMillis() alignment with getEventTime().
 */
public class MotionEventExtractor {

    private MotionEventExtractor() {}

    /**
     * Extract a complete TouchEvent from a MotionEvent.
     *
     * @param event              The MotionEvent — read immediately, do not cache.
     * @param gestureStartTimeMs eventTime of the ACTION_DOWN that opened this gesture.
     */
    public static TouchEvent extract(MotionEvent event, long gestureStartTimeMs) {

        int tMs    = (int) (event.getEventTime() - gestureStartTimeMs);
        String action = decodeAction(event.getActionMasked());

        // ── Pointers ──────────────────────────────────────────────────────
        int pointerCount = event.getPointerCount();
        List<PointerSample> pointers = new ArrayList<>(pointerCount);

        for (int i = 0; i < pointerCount; i++) {
            PointerSample ps = new PointerSample();
            ps.pointerId   = event.getPointerId(i);
            ps.toolType    = event.getToolType(i);
            ps.x           = event.getX(i);
            ps.y           = event.getY(i);
            // getRawX/Y only safe for pointer 0
            ps.rawX        = (i == 0) ? event.getRawX()  : event.getX(i);
            ps.rawY        = (i == 0) ? event.getRawY()  : event.getY(i);
            ps.pressure    = event.getPressure(i);
            ps.touchMajor  = event.getTouchMajor(i);
            ps.touchMinor  = event.getTouchMinor(i);
            ps.toolMajor   = event.getToolMajor(i);
            ps.toolMinor   = event.getToolMinor(i);
            ps.orientation = event.getOrientation(i);
            ps.tiltX       = event.getAxisValue(MotionEvent.AXIS_TILT, i);
            ps.tiltY       = event.getAxisValue(MotionEvent.AXIS_TILT, i); // same axis, direction from orientation
            ps.distance    = event.getAxisValue(MotionEvent.AXIS_DISTANCE, i);
            pointers.add(ps);
        }

        // ── Event-level metadata ──────────────────────────────────────────
        int buttonState = event.getButtonState();
        int metaState   = event.getMetaState();
        int edgeFlags   = event.getEdgeFlags();
        int flags       = event.getFlags();
        float vscroll   = event.getAxisValue(MotionEvent.AXIS_VSCROLL);
        float hscroll   = event.getAxisValue(MotionEvent.AXIS_HSCROLL);

        // ── Historical sub-samples ────────────────────────────────────────
        // MUST be read here — pointer to underlying native data is not retained
        int histSize = event.getHistorySize();
        List<HistoricalSample> historical = new ArrayList<>(histSize);

        for (int h = 0; h < histSize; h++) {
            int hTms = (int) (event.getHistoricalEventTime(h) - gestureStartTimeMs);
            List<HistoricalPointer> hPointers = new ArrayList<>(pointerCount);

            for (int i = 0; i < pointerCount; i++) {
                HistoricalPointer hp = new HistoricalPointer();
                hp.pointerId  = event.getPointerId(i);
                hp.x          = event.getHistoricalX(i, h);
                hp.y          = event.getHistoricalY(i, h);
                hp.pressure   = event.getHistoricalPressure(i, h);
                hp.touchMajor = event.getHistoricalTouchMajor(i, h);
                hp.touchMinor = event.getHistoricalTouchMinor(i, h);
                hPointers.add(hp);
            }
            historical.add(new HistoricalSample(hTms, hPointers));
        }

        return new TouchEvent(tMs, action, pointers,
                              buttonState, metaState, edgeFlags, flags,
                              vscroll, hscroll, historical);
    }

    private static String decodeAction(int maskedAction) {
        switch (maskedAction) {
            case MotionEvent.ACTION_DOWN:          return "DOWN";
            case MotionEvent.ACTION_MOVE:          return "MOVE";
            case MotionEvent.ACTION_UP:            return "UP";
            case MotionEvent.ACTION_CANCEL:        return "CANCEL";
            case MotionEvent.ACTION_POINTER_DOWN:  return "POINTER_DOWN";
            case MotionEvent.ACTION_POINTER_UP:    return "POINTER_UP";
            default:                               return "UNKNOWN";
        }
    }
}
