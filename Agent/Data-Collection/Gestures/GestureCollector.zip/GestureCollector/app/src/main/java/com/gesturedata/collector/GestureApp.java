package com.gesturedata.collector;

import android.app.Application;
import com.gesturedata.collector.data.repository.GestureRepository;
import com.gesturedata.collector.upload.UploadScheduler;

public class GestureApp extends Application {

    private static GestureApp instance;
    private GestureRepository repository;

    @Override
    public void onCreate() {
        super.onCreate();
        instance   = this;
        repository = new GestureRepository(this);
        UploadScheduler.schedule(this);
    }

    public static GestureApp get() { return instance; }

    public GestureRepository getRepository() { return repository; }
}
