package com.gesturedata.collector.data.model;

public enum SpeedCue {
    SLOW("slow", "Slow", "Move slowly and deliberately"),
    NORMAL("normal", "Normal", "Move at your natural speed"),
    FAST("fast", "Fast", "Move as fast as comfortable");

    public final String label;
    public final String displayName;
    public final String instruction;

    SpeedCue(String label, String displayName, String instruction) {
        this.label       = label;
        this.displayName = displayName;
        this.instruction = instruction;
    }
}
