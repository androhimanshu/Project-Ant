package com.gesturedata.collector.recording;

import com.gesturedata.collector.data.model.TouchEvent;
import java.util.ArrayList;
import java.util.List;

/**
 * Thread-safe ring buffer that accumulates TouchEvents during a gesture.
 * Cleared on each new ACTION_DOWN. Drained on ACTION_UP.
 * Max capacity 512 — enough for ~8 seconds at 60Hz.
 */
public class RawEventBuffer {

    private static final int MAX_CAPACITY = 512;

    private final List<TouchEvent> buffer = new ArrayList<>(MAX_CAPACITY);
    private final Object lock = new Object();

    public void clear() {
        synchronized (lock) {
            buffer.clear();
        }
    }

    public void add(TouchEvent event) {
        synchronized (lock) {
            if (buffer.size() >= MAX_CAPACITY) {
                // Drop oldest to prevent unbounded growth
                buffer.remove(0);
            }
            buffer.add(event);
        }
    }

    /**
     * Returns a copy of all buffered events and clears the buffer.
     */
    public List<TouchEvent> drain() {
        synchronized (lock) {
            List<TouchEvent> copy = new ArrayList<>(buffer);
            buffer.clear();
            return copy;
        }
    }

    public int size() {
        synchronized (lock) {
            return buffer.size();
        }
    }
}
