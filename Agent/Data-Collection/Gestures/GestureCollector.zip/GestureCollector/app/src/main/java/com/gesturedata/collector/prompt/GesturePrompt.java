package com.gesturedata.collector.prompt;

import android.graphics.PointF;
import android.graphics.RectF;
import com.gesturedata.collector.data.model.GestureType;
import com.gesturedata.collector.data.model.SpeedCue;

/**
 * Describes exactly what gesture the user should perform,
 * including where to start, where to end, and visual target zone.
 */
public class GesturePrompt {

    public final GestureType gestureType;
    public final SpeedCue    speedCue;
    public final RectF       targetZone;   // highlighted region on screen
    public final PointF      startHint;    // green dot
    public final PointF      endHint;      // red dot (null for tap)
    public final String      instruction;  // display text
    public final String      targetType;   // "button","scroll_area" etc
    public final int         targetSizePx;

    public GesturePrompt(GestureType gestureType, SpeedCue speedCue,
                         RectF targetZone, PointF startHint, PointF endHint,
                         String instruction, String targetType, int targetSizePx) {
        this.gestureType  = gestureType;
        this.speedCue     = speedCue;
        this.targetZone   = targetZone;
        this.startHint    = startHint;
        this.endHint      = endHint;
        this.instruction  = instruction;
        this.targetType   = targetType;
        this.targetSizePx = targetSizePx;
    }
}
