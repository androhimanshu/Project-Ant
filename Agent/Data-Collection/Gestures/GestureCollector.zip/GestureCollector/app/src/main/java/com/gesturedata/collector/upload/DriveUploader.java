package com.gesturedata.collector.upload;

import android.content.Context;
import android.util.Log;

import com.google.api.client.extensions.android.http.AndroidHttp;
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.services.drive.Drive;
import com.google.api.services.drive.DriveScopes;
import com.google.api.services.drive.model.File;
import com.google.api.services.drive.model.FileList;

import java.io.FileInputStream;
import java.util.Collections;

/**
 * Uploads .jsonl.gz files to a Google Drive folder named "GestureCollector/sessions/".
 * Requires Google Sign-In — account set externally before use.
 */
public class DriveUploader {

    private static final String TAG         = "DriveUploader";
    private static final String FOLDER_NAME = "GestureCollector";
    private static final String SUB_FOLDER  = "sessions";
    private static final String APP_NAME    = "GestureCollector";

    private final Context context;
    private String        accountName; // set after Google Sign-In
    private String        cachedFolderId;

    public DriveUploader(Context context) {
        this.context = context.getApplicationContext();
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
        this.cachedFolderId = null;
    }

    public boolean isConfigured() {
        return accountName != null && !accountName.isEmpty();
    }

    /**
     * Uploads a file to Google Drive sessions folder.
     * Must NOT be called on the main thread.
     * @return true if uploaded successfully
     */
    public boolean upload(java.io.File localFile, String remoteName) {
        if (!isConfigured()) {
            Log.w(TAG, "No Google account set — skipping upload");
            return false;
        }

        try {
            Drive driveService = buildDriveService();

            // Ensure folder hierarchy exists
            String folderId = ensureSessionsFolder(driveService);

            // Upload the file
            File fileMetadata = new File();
            fileMetadata.setName(remoteName);
            fileMetadata.setParents(Collections.singletonList(folderId));

            com.google.api.client.http.FileContent mediaContent =
                    new com.google.api.client.http.FileContent(
                            "application/gzip", localFile);

            driveService.files()
                    .create(fileMetadata, mediaContent)
                    .setFields("id, name")
                    .execute();

            Log.d(TAG, "Uploaded to Drive: " + remoteName);
            return true;

        } catch (Exception e) {
            Log.e(TAG, "Drive upload failed: " + remoteName, e);
            return false;
        }
    }

    private Drive buildDriveService() {
        GoogleAccountCredential credential = GoogleAccountCredential
                .usingOAuth2(context, Collections.singleton(DriveScopes.DRIVE_FILE));
        credential.setSelectedAccountName(accountName);

        return new Drive.Builder(
                AndroidHttp.newCompatibleTransport(),
                JacksonFactory.getDefaultInstance(),
                credential)
                .setApplicationName(APP_NAME)
                .build();
    }

    private String ensureSessionsFolder(Drive service) throws Exception {
        if (cachedFolderId != null) return cachedFolderId;

        // Find or create root folder
        String rootId = findOrCreateFolder(service, FOLDER_NAME, "root");
        // Find or create sub-folder
        cachedFolderId = findOrCreateFolder(service, SUB_FOLDER, rootId);
        return cachedFolderId;
    }

    private String findOrCreateFolder(Drive service, String name,
                                      String parentId) throws Exception {
        String query = "mimeType='application/vnd.google-apps.folder'"
                + " and name='" + name + "'"
                + " and '" + parentId + "' in parents"
                + " and trashed=false";

        FileList result = service.files().list()
                .setQ(query)
                .setFields("files(id, name)")
                .execute();

        if (!result.getFiles().isEmpty()) {
            return result.getFiles().get(0).getId();
        }

        // Create it
        File folderMeta = new File();
        folderMeta.setName(name);
        folderMeta.setMimeType("application/vnd.google-apps.folder");
        folderMeta.setParents(Collections.singletonList(parentId));

        File created = service.files()
                .create(folderMeta)
                .setFields("id")
                .execute();
        return created.getId();
    }
}
