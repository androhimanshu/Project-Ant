package com.gesturedata.collector.data.model;

import com.google.gson.annotations.SerializedName;
import java.util.List;

/**
 * One complete gesture recording — the top-level JSON object written per line
 * to the .jsonl output file. Field names match exactly what the Colab
 * preprocess_jsonl_to_hdf5() function expects.
 */
public class GestureRecord {

    // ── Identity ─────────────────────────────────────────────────────────

    @SerializedName("gesture_id")
    public String gestureId;

    @SerializedName("session_id")
    public String sessionId;

    @SerializedName("user_id")
    public String userId;

    // ── Gesture description ───────────────────────────────────────────────

    /** "tap", "swipe_up", "pinch_in" etc. — matches GestureType.label */
    @SerializedName("type")
    public String type;

    /** "up","down","left","right","up_left",... — null for tap/pinch */
    @SerializedName("direction")
    public String direction;

    /** "single","double" — for taps */
    @SerializedName("subtype")
    public String subtype;

    /** "slow","normal","fast" */
    @SerializedName("speed_cue")
    public String speedCue;

    // ── Device ────────────────────────────────────────────────────────────

    @SerializedName("device_model")
    public String deviceModel;

    @SerializedName("android_version")
    public int androidVersion;

    @SerializedName("screen_width")
    public int screenWidth;

    @SerializedName("screen_height")
    public int screenHeight;

    @SerializedName("dpi")
    public int dpi;

    @SerializedName("screen_refresh_rate_hz")
    public float screenRefreshRateHz;

    /** Estimated from event density during first session */
    @SerializedName("touch_sample_rate_hz")
    public int touchSampleRateHz;

    // ── Geometry ──────────────────────────────────────────────────────────

    @SerializedName("duration_ms")
    public int durationMs;

    @SerializedName("start_x")
    public float startX;

    @SerializedName("start_y")
    public float startY;

    @SerializedName("end_x")
    public Float endX;

    @SerializedName("end_y")
    public Float endY;

    @SerializedName("distance_px")
    public float distancePx;

    @SerializedName("velocity_px_per_sec")
    public float velocityPxPerSec;

    // ── User context ──────────────────────────────────────────────────────

    /** "right_thumb","right_index","left_index" etc. */
    @SerializedName("finger")
    public String finger;

    /** "right","left" */
    @SerializedName("handedness")
    public String handedness;

    /** "button","link","input","scroll_area","empty" */
    @SerializedName("target_type")
    public String targetType;

    @SerializedName("target_size_px")
    public int targetSizePx;

    // ── Collection quality ────────────────────────────────────────────────

    /** 1 = first attempt, 2+ = after retry */
    @SerializedName("attempt_number")
    public int attemptNumber;

    @SerializedName("was_retried")
    public boolean wasRetried;

    /** Milliseconds user waited after prompt appeared before touching screen */
    @SerializedName("prompt_shown_duration_ms")
    public int promptShownDurationMs;

    @SerializedName("quality_score")
    public int qualityScore;

    @SerializedName("recorded_at")
    public long recordedAt;

    // ── Touch data ────────────────────────────────────────────────────────

    @SerializedName("events")
    public List<TouchEvent> events;

    @SerializedName("derived")
    public DerivedFeatures derived;

    public GestureRecord() {}
}
