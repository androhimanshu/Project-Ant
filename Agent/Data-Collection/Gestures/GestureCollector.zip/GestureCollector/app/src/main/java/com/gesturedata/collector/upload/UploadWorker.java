package com.gesturedata.collector.upload;

import android.content.Context;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import com.gesturedata.collector.GestureApp;
import com.gesturedata.collector.data.db.GestureDao;
import com.gesturedata.collector.data.db.GestureEntity;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.zip.GZIPOutputStream;

/**
 * Background WorkManager job that:
 * 1. Groups pending .jsonl files
 * 2. GZIPs each one
 * 3. Uploads to Google Drive
 * 4. Marks gestures as uploaded in Room DB
 *
 * Runs on WiFi only, every 6 hours.
 * Retries with exponential backoff on failure.
 */
public class UploadWorker extends Worker {

    private static final String TAG = "UploadWorker";

    public UploadWorker(@NonNull Context context,
                        @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        Log.d(TAG, "Upload worker started");

        GestureDao gestureDao = GestureApp.get().getRepository().getGestureDao();
        List<GestureEntity> pending = gestureDao.getPendingUpload();

        if (pending.isEmpty()) {
            Log.d(TAG, "Nothing to upload");
            return Result.success();
        }

        Log.d(TAG, "Pending gestures: " + pending.size());

        // Group by file path
        Map<String, List<GestureEntity>> byFile = new HashMap<>();
        for (GestureEntity entity : pending) {
            if (entity.filePath == null) continue;
            if (!byFile.containsKey(entity.filePath)) {
                byFile.put(entity.filePath, new ArrayList<>());
            }
            byFile.get(entity.filePath).add(entity);
        }

        DriveUploader uploader = new DriveUploader(getApplicationContext());

        for (Map.Entry<String, List<GestureEntity>> entry : byFile.entrySet()) {
            String filePath = entry.getKey();
            List<GestureEntity> fileGestures = entry.getValue();

            File sourceFile = new File(filePath);
            if (!sourceFile.exists()) {
                Log.w(TAG, "File missing: " + filePath);
                continue;
            }

            File gzFile = new File(filePath + ".gz");
            try {
                // Compress
                compressToGzip(sourceFile, gzFile);

                // Upload
                boolean success = uploader.upload(gzFile, gzFile.getName());
                if (success) {
                    for (GestureEntity entity : fileGestures) {
                        gestureDao.markUploaded(entity.gestureId);
                    }
                    gzFile.delete();
                    Log.d(TAG, "Uploaded: " + gzFile.getName());
                } else {
                    gzFile.delete();
                    Log.w(TAG, "Upload failed for: " + filePath);
                    return Result.retry();
                }

            } catch (Exception e) {
                Log.e(TAG, "Error processing " + filePath, e);
                if (gzFile.exists()) gzFile.delete();
                return Result.retry();
            }
        }

        return Result.success();
    }

    private void compressToGzip(File source, File dest) throws Exception {
        byte[] buffer = new byte[8192];
        try (FileInputStream fis = new FileInputStream(source);
             GZIPOutputStream gos = new GZIPOutputStream(
                     new FileOutputStream(dest))) {
            int len;
            while ((len = fis.read(buffer)) > 0) {
                gos.write(buffer, 0, len);
            }
        }
    }
}
