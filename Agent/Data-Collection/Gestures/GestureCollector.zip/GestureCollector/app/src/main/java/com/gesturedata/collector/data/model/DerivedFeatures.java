package com.gesturedata.collector.data.model;

import com.google.gson.annotations.SerializedName;

/**
 * Pre-computed training features extracted from the raw touch event stream.
 * Saved alongside raw events so the Colab pipeline doesn't recompute them.
 */
public class DerivedFeatures {

    /** Maximum pressure value recorded during the gesture (0.0–1.0) */
    @SerializedName("pressure_peak")
    public float pressurePeak;

    /** Time from ACTION_DOWN until pressure reached 50% of peak (ms) */
    @SerializedName("pressure_attack_ms")
    public int pressureAttackMs;

    /** Time from last >20% pressure event until ACTION_UP (ms) */
    @SerializedName("pressure_release_ms")
    public int pressureReleaseMs;

    /** Maximum touch_major value during gesture (pixels) */
    @SerializedName("touch_major_peak")
    public float touchMajorPeak;

    /**
     * RMS of perpendicular residuals from best-fit straight line through path.
     * Measures natural hand tremor/jitter. Typical human: 0.5–3.0px.
     */
    @SerializedName("jitter_amplitude_px")
    public float jitterAmplitudePx;

    /**
     * Ratio of straight-line distance to actual path length.
     * 1.0 = perfectly straight, lower = curved path.
     */
    @SerializedName("path_linearity")
    public float pathLinearity;

    /**
     * Detected velocity profile shape.
     * "linear" | "ease_in" | "ease_out" | "ease_in_out"
     */
    @SerializedName("velocity_profile")
    public String velocityProfile;

    /** Total number of MotionEvents in gesture */
    @SerializedName("event_count")
    public int eventCount;

    /** Average number of historical sub-samples per MotionEvent */
    @SerializedName("samples_per_event_avg")
    public float samplesPerEventAvg;

    /** Maximum Euclidean distance from start point during gesture (pixels) */
    @SerializedName("max_displacement_from_start_px")
    public float maxDisplacementFromStartPx;

    public DerivedFeatures() {}

    public DerivedFeatures(float pressurePeak, int pressureAttackMs,
                           int pressureReleaseMs, float touchMajorPeak,
                           float jitterAmplitudePx, float pathLinearity,
                           String velocityProfile, int eventCount,
                           float samplesPerEventAvg,
                           float maxDisplacementFromStartPx) {
        this.pressurePeak               = pressurePeak;
        this.pressureAttackMs           = pressureAttackMs;
        this.pressureReleaseMs          = pressureReleaseMs;
        this.touchMajorPeak             = touchMajorPeak;
        this.jitterAmplitudePx          = jitterAmplitudePx;
        this.pathLinearity              = pathLinearity;
        this.velocityProfile            = velocityProfile;
        this.eventCount                 = eventCount;
        this.samplesPerEventAvg         = samplesPerEventAvg;
        this.maxDisplacementFromStartPx = maxDisplacementFromStartPx;
    }
}
