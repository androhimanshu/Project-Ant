package com.gesturedata.collector.data.repository;

import android.content.Context;
import android.os.Build;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.WindowManager;

import com.gesturedata.collector.data.model.UserProfile;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Provides device metadata included in every GestureRecord.
 * Computes a one-way anonymized user ID from Android ID + salt.
 */
public class DeviceInfoProvider {

    public static class DeviceInfo {
        public final String      model;
        public final int         androidVersion;
        public final int         screenWidth;
        public final int         screenHeight;
        public final int         dpi;
        public final float       refreshRateHz;
        public final int         estimatedTouchSampleRateHz;
        public final String      anonymizedUserId;
        public UserProfile       userProfile;

        public DeviceInfo(String model, int androidVersion,
                          int screenWidth, int screenHeight, int dpi,
                          float refreshRateHz, int estimatedTouchSampleRateHz,
                          String anonymizedUserId, UserProfile userProfile) {
            this.model                       = model;
            this.androidVersion              = androidVersion;
            this.screenWidth                 = screenWidth;
            this.screenHeight                = screenHeight;
            this.dpi                         = dpi;
            this.refreshRateHz               = refreshRateHz;
            this.estimatedTouchSampleRateHz  = estimatedTouchSampleRateHz;
            this.anonymizedUserId            = anonymizedUserId;
            this.userProfile                 = userProfile;
        }
    }

    private final Context context;
    private DeviceInfo    cached;

    public DeviceInfoProvider(Context context) {
        this.context = context.getApplicationContext();
    }

    public DeviceInfo get(UserProfile profile) {
        if (cached == null || cached.userProfile != profile) {
            cached = build(profile);
        }
        return cached;
    }

    private DeviceInfo build(UserProfile profile) {
        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        Display display = wm.getDefaultDisplay();
        DisplayMetrics metrics = new DisplayMetrics();
        display.getRealMetrics(metrics);

        String model           = Build.MANUFACTURER + " " + Build.MODEL;
        int    androidVersion  = Build.VERSION.SDK_INT;
        int    screenWidth     = metrics.widthPixels;
        int    screenHeight    = metrics.heightPixels;
        int    dpi             = metrics.densityDpi;
        float  refreshRateHz   = display.getRefreshRate();

        // Touch sample rate: estimated from event density; default 120 Hz
        // Will be updated after first session via PreferenceManager
        int estimatedTouchHz = 120;

        String userId = computeAnonymizedId();
        return new DeviceInfo(model, androidVersion, screenWidth, screenHeight,
                              dpi, refreshRateHz, estimatedTouchHz, userId, profile);
    }

    private String computeAnonymizedId() {
        try {
            String androidId = Settings.Secure.getString(
                    context.getContentResolver(), Settings.Secure.ANDROID_ID);
            if (androidId == null) androidId = "unknown";
            String input = androidId + "_gesture_collector_v1";
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(input.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 8; i++) { // use first 8 bytes = 16 hex chars
                sb.append(String.format("%02x", hash[i]));
            }
            return "u_" + sb.toString();
        } catch (Exception e) {
            return "u_unknown";
        }
    }
}
