package com.gesturedata.collector.data.db;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import java.util.List;

@Dao
public interface SessionDao {

    @Insert
    void insert(SessionEntity entity);

    @Update
    void update(SessionEntity entity);

    @Query("SELECT * FROM sessions ORDER BY startedAt DESC")
    LiveData<List<SessionEntity>> getAllSessions();

    @Query("SELECT * FROM sessions WHERE sessionId = :id")
    SessionEntity getById(String id);
}
