package com.gesturedata.collector.ui;

import android.accounts.Account;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.work.WorkInfo;

import com.gesturedata.collector.GestureApp;
import com.gesturedata.collector.R;
import com.gesturedata.collector.upload.DriveUploader;
import com.gesturedata.collector.upload.UploadScheduler;
import com.gesturedata.collector.util.PreferencesManager;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.Scope;
import com.google.api.services.drive.DriveScopes;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class UploadActivity extends AppCompatActivity {

    private static final int RC_SIGN_IN = 1001;

    private TextView    tvStatus;
    private TextView    tvAccountName;
    private ProgressBar progressBar;
    private Button      btnSignIn;
    private Button      btnUploadNow;
    private Button      btnDone;

    private GoogleSignInClient signInClient;
    private PreferencesManager prefs;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload);

        prefs = PreferencesManager.getInstance(this);

        tvStatus      = findViewById(R.id.tvUploadStatus);
        tvAccountName = findViewById(R.id.tvAccountName);
        progressBar   = findViewById(R.id.uploadProgressBar);
        btnSignIn     = findViewById(R.id.btnSignIn);
        btnUploadNow  = findViewById(R.id.btnUploadNow);
        btnDone       = findViewById(R.id.btnDone);

        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .requestScopes(new Scope(DriveScopes.DRIVE_FILE))
                .build();
        signInClient = GoogleSignIn.getClient(this, gso);

        updateSignInUi();

        btnSignIn.setOnClickListener(v ->
                startActivityForResult(signInClient.getSignInIntent(), RC_SIGN_IN));

        btnUploadNow.setOnClickListener(v -> {
            tvStatus.setText("Queuing upload…");
            progressBar.setVisibility(View.VISIBLE);
            UploadScheduler.scheduleImmediate(this);
            tvStatus.setText("Upload running in background. You can close this screen.");
            progressBar.setVisibility(View.GONE);
        });

        btnDone.setOnClickListener(v -> finish());

        // Show pending count
        executor.execute(() -> {
            int pending = GestureApp.get().getRepository()
                    .getGestureDao().pendingUploadCount();
            runOnUiThread(() ->
                    tvStatus.setText(pending + " gesture files pending upload"));
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RC_SIGN_IN) {
            GoogleSignIn.getSignedInAccountFromIntent(data)
                    .addOnSuccessListener(account -> {
                        prefs.setDriveAccountName(account.getEmail());
                        updateSignInUi();
                        Toast.makeText(this,
                                "Signed in as " + account.getEmail(),
                                Toast.LENGTH_SHORT).show();
                    })
                    .addOnFailureListener(e ->
                            Toast.makeText(this,
                                    "Sign-in failed: " + e.getMessage(),
                                    Toast.LENGTH_LONG).show());
        }
    }

    private void updateSignInUi() {
        String account = prefs.getDriveAccountName();
        if (account != null) {
            tvAccountName.setText("Signed in: " + account);
            btnSignIn.setText("Switch Account");
            btnUploadNow.setEnabled(true);
        } else {
            tvAccountName.setText("Not signed in");
            btnSignIn.setText("Sign in with Google");
            btnUploadNow.setEnabled(false);
        }
    }
}
