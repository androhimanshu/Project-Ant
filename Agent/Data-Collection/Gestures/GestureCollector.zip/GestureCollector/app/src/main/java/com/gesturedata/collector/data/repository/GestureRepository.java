package com.gesturedata.collector.data.repository;

import android.content.Context;

import com.gesturedata.collector.data.db.AppDatabase;
import com.gesturedata.collector.data.db.GestureDao;
import com.gesturedata.collector.data.db.GestureEntity;
import com.gesturedata.collector.data.db.SessionDao;
import com.gesturedata.collector.data.db.SessionEntity;
import com.gesturedata.collector.data.model.DerivedFeatures;
import com.gesturedata.collector.data.model.GestureRecord;
import com.gesturedata.collector.data.model.PointerSample;
import com.gesturedata.collector.data.model.TouchEvent;
import com.gesturedata.collector.data.model.UserProfile;
import com.gesturedata.collector.prompt.GesturePrompt;
import com.gesturedata.collector.recording.DerivedFeatureComputer;
import com.gesturedata.collector.recording.QualityValidator;
import com.gesturedata.collector.storage.JsonlWriter;

import java.io.File;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Orchestrates the full save pipeline:
 * events → derived features → GestureRecord → .jsonl + Room DB
 *
 * All disk/DB operations run on a dedicated single-thread executor.
 */
public class GestureRepository {

    public interface SaveCallback {
        void onSaved(String gestureId);
        void onError(Exception e);
    }

    private final GestureDao          gestureDao;
    private final SessionDao          sessionDao;
    private final JsonlWriter          jsonlWriter;
    private final DeviceInfoProvider   deviceInfoProvider;
    private final ExecutorService      executor;

    private SessionEntity currentSession;
    private int           sessionGestureCount = 0;

    public GestureRepository(Context context) {
        AppDatabase db = AppDatabase.getInstance(context);
        this.gestureDao         = db.gestureDao();
        this.sessionDao         = db.sessionDao();
        this.jsonlWriter        = new JsonlWriter(getSessionsDir(context));
        this.deviceInfoProvider = new DeviceInfoProvider(context);
        this.executor           = Executors.newSingleThreadExecutor();
    }

    private File getSessionsDir(Context context) {
        File base = context.getExternalFilesDir("gesture_sessions");
        if (base == null) base = new File(context.getFilesDir(), "gesture_sessions");
        if (!base.exists()) base.mkdirs();
        return base;
    }

    // ── Session lifecycle ─────────────────────────────────────────────────

    public void startSession(Runnable onDone) {
        executor.execute(() -> {
            try {
                String sessionId = UUID.randomUUID().toString();
                String filePath  = jsonlWriter.openSession(sessionId);
                currentSession = new SessionEntity(
                        sessionId,
                        System.currentTimeMillis(),
                        0L, 0, 0, filePath);
                sessionDao.insert(currentSession);
                sessionGestureCount = 0;
                if (onDone != null) onDone.run();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public void endSession(Runnable onDone) {
        executor.execute(() -> {
            jsonlWriter.close();
            if (currentSession != null) {
                currentSession.endedAt      = System.currentTimeMillis();
                currentSession.gestureCount = sessionGestureCount;
                sessionDao.update(currentSession);
            }
            if (onDone != null) onDone.run();
        });
    }

    // ── Save gesture ──────────────────────────────────────────────────────

    public void saveGesture(List<TouchEvent> events,
                            GesturePrompt prompt,
                            QualityValidator.ValidationResult validationResult,
                            int promptShownDurationMs,
                            int attemptNumber,
                            UserProfile userProfile,
                            SaveCallback callback) {
        executor.execute(() -> {
            try {
                DerivedFeatures derived = DerivedFeatureComputer.compute(events);
                DeviceInfoProvider.DeviceInfo device =
                        deviceInfoProvider.get(userProfile);

                // Extract geometry
                TouchEvent downEvent = findEventByAction(events, "DOWN");
                TouchEvent upEvent   = findLastEventByAction(events, "UP");
                if (downEvent == null || upEvent == null) {
                    if (callback != null) callback.onError(
                            new IllegalStateException("Missing DOWN/UP events"));
                    return;
                }
                PointerSample startPtr = downEvent.pointers.get(0);
                PointerSample endPtr   = upEvent.pointers.get(0);
                int durationMs = upEvent.tMs - downEvent.tMs;

                float distancePx   = derived.maxDisplacementFromStartPx;
                float velocityPxPerSec = durationMs > 0
                        ? distancePx / (durationMs / 1000f) : 0f;

                GestureRecord record = new GestureRecord();
                record.gestureId             = UUID.randomUUID().toString();
                record.sessionId             = currentSession != null
                        ? currentSession.sessionId : "no_session";
                record.userId                = device.anonymizedUserId;
                record.type                  = prompt.gestureType.label;
                record.direction             = prompt.gestureType.defaultDirection;
                record.subtype               = prompt.gestureType == com.gesturedata.collector.data.model.GestureType.DOUBLE_TAP ? "double" : "single";
                record.speedCue              = prompt.speedCue.label;
                record.deviceModel           = device.model;
                record.androidVersion        = device.androidVersion;
                record.screenWidth           = device.screenWidth;
                record.screenHeight          = device.screenHeight;
                record.dpi                   = device.dpi;
                record.screenRefreshRateHz   = device.refreshRateHz;
                record.touchSampleRateHz     = device.estimatedTouchSampleRateHz;
                record.durationMs            = durationMs;
                record.startX                = startPtr.x;
                record.startY                = startPtr.y;
                record.endX                  = endPtr.x;
                record.endY                  = endPtr.y;
                record.distancePx            = distancePx;
                record.velocityPxPerSec      = velocityPxPerSec;
                record.finger                = userProfile.finger;
                record.handedness            = userProfile.handedness;
                record.targetType            = prompt.targetType;
                record.targetSizePx          = prompt.targetSizePx;
                record.attemptNumber         = attemptNumber;
                record.wasRetried            = attemptNumber > 1;
                record.promptShownDurationMs = promptShownDurationMs;
                record.qualityScore          = validationResult.score;
                record.recordedAt            = System.currentTimeMillis();
                record.events                = events;
                record.derived               = derived;

                jsonlWriter.appendGesture(record);

                GestureEntity entity = new GestureEntity(
                        record.gestureId,
                        record.sessionId,
                        record.type,
                        record.direction,
                        record.durationMs,
                        record.qualityScore,
                        jsonlWriter.getCurrentFilePath(),
                        false,
                        record.recordedAt);
                gestureDao.insert(entity);
                sessionGestureCount++;

                if (callback != null) callback.onSaved(record.gestureId);

            } catch (Exception e) {
                e.printStackTrace();
                if (callback != null) callback.onError(e);
            }
        });
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    private TouchEvent findEventByAction(List<TouchEvent> events, String action) {
        for (TouchEvent e : events) {
            if (action.equals(e.action)) return e;
        }
        return null;
    }

    private TouchEvent findLastEventByAction(List<TouchEvent> events, String action) {
        TouchEvent last = null;
        for (TouchEvent e : events) {
            if (action.equals(e.action)) last = e;
        }
        return last;
    }

    public GestureDao   getGestureDao()  { return gestureDao; }
    public SessionDao   getSessionDao()  { return sessionDao; }
}
