package com.gesturedata.collector.data.db;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.annotation.NonNull;

@Entity(tableName = "gestures")
public class GestureEntity {

    @PrimaryKey
    @NonNull
    public String gestureId;

    @NonNull
    public String sessionId;

    public String type;
    public String direction;
    public int    durationMs;
    public int    qualityScore;

    /** Absolute path to the .jsonl file containing this gesture */
    public String filePath;

    public boolean uploaded;
    public long    recordedAt;

    public GestureEntity() {}

    public GestureEntity(@NonNull String gestureId, @NonNull String sessionId,
                         String type, String direction, int durationMs,
                         int qualityScore, String filePath,
                         boolean uploaded, long recordedAt) {
        this.gestureId   = gestureId;
        this.sessionId   = sessionId;
        this.type        = type;
        this.direction   = direction;
        this.durationMs  = durationMs;
        this.qualityScore= qualityScore;
        this.filePath    = filePath;
        this.uploaded    = uploaded;
        this.recordedAt  = recordedAt;
    }
}
