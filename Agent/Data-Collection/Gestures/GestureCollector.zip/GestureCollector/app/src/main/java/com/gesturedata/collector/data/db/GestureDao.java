package com.gesturedata.collector.data.db;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import java.util.List;

@Dao
public interface GestureDao {

    @Insert
    void insert(GestureEntity entity);

    @Query("SELECT * FROM gestures WHERE uploaded = 0")
    List<GestureEntity> getPendingUpload();

    @Query("UPDATE gestures SET uploaded = 1 WHERE gestureId = :id")
    void markUploaded(String id);

    @Query("SELECT COUNT(*) FROM gestures")
    int totalCount();

    @Query("SELECT COUNT(*) FROM gestures")
    LiveData<Integer> totalCountLive();

    @Query("SELECT COUNT(*) FROM gestures WHERE recordedAt > :since")
    int countSince(long since);

    @Query("SELECT COUNT(*) FROM gestures WHERE type = :type")
    int countByType(String type);

    @Query("SELECT type, COUNT(*) as cnt FROM gestures GROUP BY type")
    List<TypeCount> countPerType();

    @Query("SELECT COUNT(*) FROM gestures WHERE uploaded = 0")
    int pendingUploadCount();

    @Query("SELECT COUNT(*) FROM gestures WHERE uploaded = 0")
    LiveData<Integer> pendingUploadCountLive();

    /** Simple projection for type-count chart */
    class TypeCount {
        public String type;
        public int    cnt;
    }
}
