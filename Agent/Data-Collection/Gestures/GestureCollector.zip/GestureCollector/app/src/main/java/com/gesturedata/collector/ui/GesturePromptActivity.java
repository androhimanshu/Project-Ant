package com.gesturedata.collector.ui;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.lifecycle.ViewModelProvider;

import com.gesturedata.collector.R;
import com.gesturedata.collector.data.model.QualityLevel;
import com.gesturedata.collector.data.model.SessionConfig;
import com.gesturedata.collector.data.model.TouchEvent;
import com.gesturedata.collector.prompt.GesturePrompt;
import com.gesturedata.collector.recording.GestureRecorderView;
import com.gesturedata.collector.viewmodel.GesturePromptViewModel;

import java.util.List;
import java.util.Locale;

public class GesturePromptActivity extends AppCompatActivity {

    // Views
    private GestureRecorderView recorderView;
    private TextView            tvProgress;
    private TextView            tvInstruction;
    private TextView            tvSpeedCue;
    private TextView            tvGestureType;
    private ProgressBar         progressBar;
    private CardView            cardResult;
    private TextView            tvQualityBadge;
    private TextView            tvResultDetail;
    private TextView            tvRejectReason;
    private Button              btnAccept;
    private Button              btnRetry;

    private GesturePromptViewModel viewModel;

    // Per-gesture ephemeral state
    private List<TouchEvent> lastEvents;
    private int              lastPromptShownMs;
    private int              lastAttemptNumber;

    // Auto-advance timer for EXCELLENT/GOOD
    private final Handler     autoHandler  = new Handler(Looper.getMainLooper());
    private static final long AUTO_DELAY   = 1800;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gesture_prompt);

        bindViews();
        setupViewModel();
        loadSessionConfig();
    }

    private void bindViews() {
        recorderView   = findViewById(R.id.gestureRecorderView);
        tvProgress     = findViewById(R.id.tvProgress);
        tvInstruction  = findViewById(R.id.tvInstruction);
        tvSpeedCue     = findViewById(R.id.tvSpeedCue);
        tvGestureType  = findViewById(R.id.tvGestureType);
        progressBar    = findViewById(R.id.progressBar);
        cardResult     = findViewById(R.id.cardResult);
        tvQualityBadge = findViewById(R.id.tvQualityBadge);
        tvResultDetail = findViewById(R.id.tvResultDetail);
        tvRejectReason = findViewById(R.id.tvRejectReason);
        btnAccept      = findViewById(R.id.btnAccept);
        btnRetry       = findViewById(R.id.btnRetry);

        cardResult.setVisibility(View.GONE);

        btnAccept.setOnClickListener(v -> {
            autoHandler.removeCallbacksAndMessages(null);
            viewModel.acceptGesture();
        });

        btnRetry.setOnClickListener(v -> {
            autoHandler.removeCallbacksAndMessages(null);
            viewModel.retryGesture();
            recorderView.resetForRetry();
            recorderView.startRecording();
            cardResult.setVisibility(View.GONE);
        });
    }

    private void setupViewModel() {
        viewModel = new ViewModelProvider(this).get(GesturePromptViewModel.class);

        viewModel.getState().observe(this, this::onStateChanged);
        viewModel.getPrompt().observe(this, this::onPromptChanged);
        viewModel.getResult().observe(this, this::onResultChanged);

        viewModel.getProgress().observe(this, progress -> {
            int total = getTotal();
            tvProgress.setText(progress + " / " + total);
            progressBar.setMax(total);
            progressBar.setProgress(progress);
        });

        viewModel.getTotal().observe(this, total -> {
            progressBar.setMax(total);
            tvProgress.setText("0 / " + total);
        });

        recorderView.setGestureCompleteListener((events, promptShownMs, attempt) -> {
            lastEvents        = events;
            lastPromptShownMs = promptShownMs;
            lastAttemptNumber = attempt;
            viewModel.onGestureRecorded(events, promptShownMs, attempt);
        });
    }

    private void loadSessionConfig() {
        String json = getIntent().getStringExtra(SessionConfigActivity.EXTRA_SESSION_CONFIG);
        if (json == null) { finish(); return; }

        SessionConfig config = new com.google.gson.Gson().fromJson(json, SessionConfig.class);
        // Fix enum deserialization for GestureType and SpeedCue
        config = rebuildConfig(config);

        android.util.DisplayMetrics dm = new android.util.DisplayMetrics();
        getWindowManager().getDefaultDisplay().getRealMetrics(dm);

        viewModel.startSession(config, dm.widthPixels, dm.heightPixels);
    }

    /**
     * Gson can't deserialize our enums by default; rebuild from labels.
     */
    private SessionConfig rebuildConfig(SessionConfig raw) {
        SessionConfig rebuilt = new SessionConfig();
        rebuilt.gesturesPerType = raw.gesturesPerType;

        if (raw.speedCue != null) {
            rebuilt.speedCue = raw.speedCue;
        }

        rebuilt.selectedTypes = new java.util.ArrayList<>();
        if (raw.selectedTypes != null) {
            for (com.gesturedata.collector.data.model.GestureType t : raw.selectedTypes) {
                if (t != null) rebuilt.selectedTypes.add(t);
            }
        }
        return rebuilt;
    }

    // ── State machine handler ─────────────────────────────────────────────

    private void onStateChanged(GesturePromptViewModel.SessionState state) {
        switch (state) {
            case RECORDING:
                cardResult.setVisibility(View.GONE);
                recorderView.startRecording();
                break;

            case SESSION_COMPLETE:
                goToSummary();
                break;

            case IDLE:
            case SHOWING_RESULT:
                break;
        }
    }

    private void onPromptChanged(GesturePrompt prompt) {
        recorderView.setPrompt(prompt);
        tvInstruction.setText(prompt.instruction);
        tvGestureType.setText(prompt.gestureType.displayName);
        tvSpeedCue.setText(prompt.speedCue.displayName.toUpperCase());
    }

    private void onResultChanged(GesturePromptViewModel.GestureResult result) {
        if (result == null) return;

        QualityLevel level = result.validation.level;

        // Update quality badge
        tvQualityBadge.setText(level.label.toUpperCase());
        tvQualityBadge.setBackgroundColor(level.color);

        // Duration and pressure stats
        tvResultDetail.setText(String.format(Locale.US,
                "Duration: %dms  |  Peak pressure: %.2f",
                result.durationMs, result.peakPressure));

        // Reject reason or empty
        if (result.validation.rejectReason != null) {
            tvRejectReason.setVisibility(View.VISIBLE);
            tvRejectReason.setText(result.validation.rejectReason);
        } else {
            tvRejectReason.setVisibility(View.GONE);
        }

        // Show result card
        cardResult.setVisibility(View.VISIBLE);

        // POOR → hide Accept, force Retry
        if (level == QualityLevel.POOR) {
            btnAccept.setVisibility(View.GONE);
            btnRetry.setText("Try Again");
        } else {
            btnAccept.setVisibility(View.VISIBLE);
            btnRetry.setText("Retry ↺");
        }

        // Auto-advance for EXCELLENT / GOOD after delay
        if (level == QualityLevel.EXCELLENT || level == QualityLevel.GOOD) {
            autoHandler.postDelayed(() -> viewModel.acceptGesture(), AUTO_DELAY);
        }
    }

    private void goToSummary() {
        Intent intent = new Intent(this, SessionSummaryActivity.class);
        GesturePromptViewModel.SessionSummary summary = viewModel.getSummary();
        intent.putExtra("total",     summary.total);
        intent.putExtra("accepted",  summary.accepted);
        intent.putExtra("rejected",  summary.rejected);
        intent.putExtra("excellent", summary.excellent);
        intent.putExtra("good",      summary.good);
        intent.putExtra("fair",      summary.fair);
        startActivity(intent);
        finish();
    }

    private int getTotal() {
        Integer t = viewModel.getTotal().getValue();
        return t != null ? t : 1;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        autoHandler.removeCallbacksAndMessages(null);
    }
}
