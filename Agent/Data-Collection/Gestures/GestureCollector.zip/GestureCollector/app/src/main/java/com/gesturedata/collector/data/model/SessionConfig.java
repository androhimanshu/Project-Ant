package com.gesturedata.collector.data.model;

import java.util.List;
import java.util.ArrayList;

/**
 * Holds the user-selected configuration for one recording session.
 * Passed from SessionConfigActivity → GesturePromptActivity.
 */
public class SessionConfig {

    public List<GestureType> selectedTypes;
    public int               gesturesPerType;
    public SpeedCue          speedCue;
    public String            sessionType; // "quick","standard","deep","custom"

    public SessionConfig() {
        selectedTypes   = new ArrayList<>();
        gesturesPerType = 10;
        speedCue        = SpeedCue.NORMAL;
        sessionType     = "standard";
    }

    public int totalGestures() {
        return selectedTypes.size() * gesturesPerType;
    }

    /** Default STANDARD session — all swipes + tap */
    public static SessionConfig standard() {
        SessionConfig c = new SessionConfig();
        c.sessionType     = "standard";
        c.gesturesPerType = 10;
        c.speedCue        = SpeedCue.NORMAL;
        c.selectedTypes.add(GestureType.TAP);
        c.selectedTypes.add(GestureType.SWIPE_UP);
        c.selectedTypes.add(GestureType.SWIPE_DOWN);
        c.selectedTypes.add(GestureType.SWIPE_LEFT);
        c.selectedTypes.add(GestureType.SWIPE_RIGHT);
        return c;
    }

    /** QUICK session — tap + swipe up/down only, 5 each */
    public static SessionConfig quick() {
        SessionConfig c = new SessionConfig();
        c.sessionType     = "quick";
        c.gesturesPerType = 5;
        c.speedCue        = SpeedCue.NORMAL;
        c.selectedTypes.add(GestureType.TAP);
        c.selectedTypes.add(GestureType.SWIPE_UP);
        c.selectedTypes.add(GestureType.SWIPE_DOWN);
        return c;
    }

    /** DEEP session — all 14 types, 10 each */
    public static SessionConfig deep() {
        SessionConfig c = new SessionConfig();
        c.sessionType     = "deep";
        c.gesturesPerType = 10;
        c.speedCue        = SpeedCue.NORMAL;
        for (GestureType t : GestureType.values()) {
            c.selectedTypes.add(t);
        }
        return c;
    }
}
