package com.gesturedata.collector.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.gesturedata.collector.R;
import com.gesturedata.collector.upload.UploadScheduler;

public class SessionSummaryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_session_summary);

        int total     = getIntent().getIntExtra("total", 0);
        int accepted  = getIntent().getIntExtra("accepted", 0);
        int rejected  = getIntent().getIntExtra("rejected", 0);
        int excellent = getIntent().getIntExtra("excellent", 0);
        int good      = getIntent().getIntExtra("good", 0);
        int fair      = getIntent().getIntExtra("fair", 0);

        TextView tvTitle     = findViewById(R.id.tvSummaryTitle);
        TextView tvAccepted  = findViewById(R.id.tvAccepted);
        TextView tvRejected  = findViewById(R.id.tvRejected);
        TextView tvExcellent = findViewById(R.id.tvExcellent);
        TextView tvGood      = findViewById(R.id.tvGood);
        TextView tvFair      = findViewById(R.id.tvFair);
        Button   btnUpload   = findViewById(R.id.btnUploadNow);
        Button   btnLater    = findViewById(R.id.btnUploadLater);
        Button   btnHome     = findViewById(R.id.btnBackHome);

        tvTitle.setText("Session Complete!");
        tvAccepted.setText("Accepted: " + accepted + " / " + total);
        tvRejected.setText("Retried:  " + rejected);
        tvExcellent.setText("Excellent: " + excellent);
        tvGood.setText("Good:      " + good);
        tvFair.setText("Fair:      " + fair);

        btnUpload.setOnClickListener(v -> {
            UploadScheduler.scheduleImmediate(this);
            startActivity(new Intent(this, UploadActivity.class));
            finish();
        });

        btnLater.setOnClickListener(v -> goHome());
        btnHome.setOnClickListener(v -> goHome());
    }

    private void goHome() {
        Intent intent = new Intent(this, HomeActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        finish();
    }

    @Override
    public void onBackPressed() {
        goHome();
    }
}
