package com.gesturedata.collector.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.gesturedata.collector.GestureApp;
import com.gesturedata.collector.data.model.GestureType;
import com.gesturedata.collector.data.model.QualityLevel;
import com.gesturedata.collector.data.model.SessionConfig;
import com.gesturedata.collector.data.model.SpeedCue;
import com.gesturedata.collector.data.model.TouchEvent;
import com.gesturedata.collector.data.model.UserProfile;
import com.gesturedata.collector.data.repository.GestureRepository;
import com.gesturedata.collector.prompt.GesturePrompt;
import com.gesturedata.collector.prompt.GesturePromptGenerator;
import com.gesturedata.collector.recording.QualityValidator;
import com.gesturedata.collector.util.PreferencesManager;

import java.util.ArrayList;
import java.util.List;

/**
 * Drives the gesture recording session state machine.
 *
 * State transitions:
 *   IDLE → RECORDING → SHOWING_RESULT → (ACCEPT → next RECORDING | RETRY → RECORDING)
 *   → SESSION_COMPLETE
 */
public class GesturePromptViewModel extends AndroidViewModel {

    public enum SessionState {
        IDLE,
        RECORDING,
        SHOWING_RESULT,
        SESSION_COMPLETE
    }

    // ── Per-gesture result package ─────────────────────────────────────────
    public static class GestureResult {
        public final QualityValidator.ValidationResult validation;
        public final List<TouchEvent>                  events;
        public final int                               promptShownMs;
        public final int                               attemptNumber;
        public final int                               durationMs;
        public final float                             peakPressure;
        public final float                             distancePx;

        public GestureResult(QualityValidator.ValidationResult validation,
                             List<TouchEvent> events,
                             int promptShownMs, int attemptNumber) {
            this.validation    = validation;
            this.events        = events;
            this.promptShownMs = promptShownMs;
            this.attemptNumber = attemptNumber;

            // Compute quick display stats
            int dur = 0; float press = 0; float dist = 0;
            if (!events.isEmpty()) {
                TouchEvent first = events.get(0);
                TouchEvent last  = events.get(events.size() - 1);
                dur = last.tMs - first.tMs;
                for (TouchEvent e : events) {
                    if (e.pointers != null) {
                        for (com.gesturedata.collector.data.model.PointerSample p : e.pointers) {
                            if (p.pressure > press) press = p.pressure;
                        }
                    }
                }
            }
            this.durationMs   = dur;
            this.peakPressure = press;
            this.distancePx   = 0; // filled from derived
        }
    }

    // ── Session summary ───────────────────────────────────────────────────
    public static class SessionSummary {
        public int total;
        public int accepted;
        public int rejected;
        public int excellent;
        public int good;
        public int fair;
    }

    // ── LiveData ──────────────────────────────────────────────────────────
    private final MutableLiveData<SessionState>  stateLive    = new MutableLiveData<>(SessionState.IDLE);
    private final MutableLiveData<GesturePrompt> promptLive   = new MutableLiveData<>();
    private final MutableLiveData<GestureResult> resultLive   = new MutableLiveData<>();
    private final MutableLiveData<Integer>       progressLive = new MutableLiveData<>(0);
    private final MutableLiveData<Integer>       totalLive    = new MutableLiveData<>(0);

    // ── Internal state ────────────────────────────────────────────────────
    private SessionConfig            config;
    private GesturePromptGenerator   promptGenerator;
    private GestureRepository        repository;
    private UserProfile              userProfile;

    private List<GestureType>        flatTypeList;   // expanded list of all slots
    private int                      currentSlot;    // which slot we're on
    private int                      attemptNumber;
    private GestureResult            pendingResult;  // waiting for Accept/Retry

    // Session summary counters
    private final SessionSummary     summary = new SessionSummary();

    // ── LiveData accessors ────────────────────────────────────────────────
    public LiveData<SessionState>  getState()    { return stateLive; }
    public LiveData<GesturePrompt> getPrompt()   { return promptLive; }
    public LiveData<GestureResult> getResult()   { return resultLive; }
    public LiveData<Integer>       getProgress() { return progressLive; }
    public LiveData<Integer>       getTotal()    { return totalLive; }
    public SessionSummary          getSummary()  { return summary; }

    public GesturePromptViewModel(@NonNull Application application) {
        super(application);
        repository  = GestureApp.get().getRepository();
        userProfile = PreferencesManager.getInstance(application).getUserProfile();
    }

    // ── Session lifecycle ─────────────────────────────────────────────────

    public void startSession(SessionConfig config, int screenWidth, int screenHeight) {
        this.config          = config;
        this.promptGenerator = new GesturePromptGenerator(screenWidth, screenHeight);
        this.currentSlot     = 0;
        this.attemptNumber   = 1;

        // Expand into flat slot list
        flatTypeList = new ArrayList<>();
        for (GestureType type : config.selectedTypes) {
            for (int i = 0; i < config.gesturesPerType; i++) {
                flatTypeList.add(type);
            }
        }

        totalLive.setValue(flatTypeList.size());
        progressLive.setValue(0);

        // Reset summary
        summary.total = flatTypeList.size();
        summary.accepted = summary.rejected = 0;
        summary.excellent = summary.good = summary.fair = 0;

        repository.startSession(() -> {
            stateLive.postValue(SessionState.RECORDING);
            loadNextPrompt();
        });
    }

    /** Called by GestureRecorderView when a gesture finishes */
    public void onGestureRecorded(List<TouchEvent> events,
                                  int promptShownMs,
                                  int attempt) {
        GesturePrompt prompt = promptLive.getValue();
        QualityValidator.ValidationResult validation =
                QualityValidator.validate(events, prompt);

        GestureResult result = new GestureResult(
                validation, events, promptShownMs, attempt);
        pendingResult = result;

        // Auto-reject POOR — skip to SHOWING_RESULT so user sees why
        stateLive.postValue(SessionState.SHOWING_RESULT);
        resultLive.postValue(result);
    }

    /** User accepted the gesture (or auto-accepted for EXCELLENT/GOOD) */
    public void acceptGesture() {
        if (pendingResult == null) return;
        GesturePrompt prompt = promptLive.getValue();

        // Update summary
        summary.accepted++;
        QualityLevel level = pendingResult.validation.level;
        if (level == QualityLevel.EXCELLENT) summary.excellent++;
        else if (level == QualityLevel.GOOD)  summary.good++;
        else if (level == QualityLevel.FAIR)  summary.fair++;

        final GestureResult saved = pendingResult;
        pendingResult = null;

        repository.saveGesture(
                saved.events, prompt, saved.validation,
                saved.promptShownMs, saved.attemptNumber,
                userProfile,
                new GestureRepository.SaveCallback() {
                    @Override public void onSaved(String id) {}
                    @Override public void onError(Exception e) { e.printStackTrace(); }
                });

        currentSlot++;
        progressLive.postValue(currentSlot);

        if (currentSlot >= flatTypeList.size()) {
            finishSession();
        } else {
            attemptNumber = 1;
            stateLive.postValue(SessionState.RECORDING);
            loadNextPrompt();
        }
    }

    /** User chose to retry the current gesture */
    public void retryGesture() {
        summary.rejected++;
        attemptNumber++;
        pendingResult = null;
        stateLive.postValue(SessionState.RECORDING);
        // Prompt stays the same — GestureRecorderView.resetForRetry() called in activity
    }

    private void loadNextPrompt() {
        if (flatTypeList == null || currentSlot >= flatTypeList.size()) return;
        GestureType type   = flatTypeList.get(currentSlot);
        SpeedCue    speed  = config.speedCue;
        GesturePrompt next = promptGenerator.generate(type, speed);
        promptLive.postValue(next);
    }

    private void finishSession() {
        repository.endSession(() -> {
            PreferencesManager.getInstance(getApplication()).recordActivityToday();
            stateLive.postValue(SessionState.SESSION_COMPLETE);
        });
    }
}
