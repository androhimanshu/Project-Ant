package com.gesturedata.collector.util;

import android.content.Context;
import android.content.SharedPreferences;

import com.gesturedata.collector.data.model.UserProfile;

/**
 * Centralized SharedPreferences wrapper.
 * Stores: onboarding completion, user profile, Drive account, touch sample rate.
 */
public class PreferencesManager {

    private static final String PREFS_NAME           = "gesture_collector_prefs";
    private static final String KEY_ONBOARDING_DONE  = "onboarding_done";
    private static final String KEY_HANDEDNESS        = "handedness";
    private static final String KEY_FINGER            = "finger";
    private static final String KEY_PHONE_FEEL        = "phone_feel";
    private static final String KEY_CONSENT_GIVEN     = "consent_given";
    private static final String KEY_DRIVE_ACCOUNT     = "drive_account";
    private static final String KEY_TOUCH_SAMPLE_HZ   = "touch_sample_hz";
    private static final String KEY_STREAK_DATE        = "streak_date";
    private static final String KEY_STREAK_COUNT       = "streak_count";
    private static final String KEY_TOTAL_TODAY        = "total_today";
    private static final String KEY_TODAY_DATE         = "today_date";

    private final SharedPreferences prefs;

    private static PreferencesManager instance;

    public static PreferencesManager getInstance(Context context) {
        if (instance == null) {
            instance = new PreferencesManager(context.getApplicationContext());
        }
        return instance;
    }

    private PreferencesManager(Context context) {
        this.prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    // ── Onboarding ────────────────────────────────────────────────────────

    public boolean isOnboardingDone() {
        return prefs.getBoolean(KEY_ONBOARDING_DONE, false);
    }

    public void setOnboardingDone(boolean done) {
        prefs.edit().putBoolean(KEY_ONBOARDING_DONE, done).apply();
    }

    public boolean isConsentGiven() {
        return prefs.getBoolean(KEY_CONSENT_GIVEN, false);
    }

    public void setConsentGiven(boolean given) {
        prefs.edit().putBoolean(KEY_CONSENT_GIVEN, given).apply();
    }

    // ── User profile ─────────────────────────────────────────────────────

    public UserProfile getUserProfile() {
        UserProfile p = new UserProfile();
        p.handedness = prefs.getString(KEY_HANDEDNESS, "right");
        p.finger     = prefs.getString(KEY_FINGER, "right_index");
        p.phoneFeel  = prefs.getString(KEY_PHONE_FEEL, "normal");
        return p;
    }

    public void saveUserProfile(UserProfile profile) {
        prefs.edit()
                .putString(KEY_HANDEDNESS, profile.handedness)
                .putString(KEY_FINGER,     profile.finger)
                .putString(KEY_PHONE_FEEL, profile.phoneFeel)
                .apply();
    }

    // ── Drive account ─────────────────────────────────────────────────────

    public String getDriveAccountName() {
        return prefs.getString(KEY_DRIVE_ACCOUNT, null);
    }

    public void setDriveAccountName(String account) {
        prefs.edit().putString(KEY_DRIVE_ACCOUNT, account).apply();
    }

    // ── Touch sample rate (estimated after first session) ─────────────────

    public int getTouchSampleRateHz() {
        return prefs.getInt(KEY_TOUCH_SAMPLE_HZ, 120);
    }

    public void setTouchSampleRateHz(int hz) {
        prefs.edit().putInt(KEY_TOUCH_SAMPLE_HZ, hz).apply();
    }

    // ── Streak tracking ───────────────────────────────────────────────────

    public int getStreak() {
        return prefs.getInt(KEY_STREAK_COUNT, 0);
    }

    public void recordActivityToday() {
        String today = new java.text.SimpleDateFormat("yyyy-MM-dd",
                java.util.Locale.US).format(new java.util.Date());
        String lastDate = prefs.getString(KEY_STREAK_DATE, "");
        int streak = prefs.getInt(KEY_STREAK_COUNT, 0);

        if (today.equals(lastDate)) return; // already recorded today

        // Check if yesterday
        java.util.Calendar cal = java.util.Calendar.getInstance();
        cal.add(java.util.Calendar.DAY_OF_YEAR, -1);
        String yesterday = new java.text.SimpleDateFormat("yyyy-MM-dd",
                java.util.Locale.US).format(cal.getTime());

        if (yesterday.equals(lastDate)) {
            streak++;
        } else {
            streak = 1; // reset streak
        }

        prefs.edit()
                .putString(KEY_STREAK_DATE, today)
                .putInt(KEY_STREAK_COUNT, streak)
                .apply();
    }
}
